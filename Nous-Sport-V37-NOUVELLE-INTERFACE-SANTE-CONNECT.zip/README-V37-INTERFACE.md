# Nous Sport V37

Refonte interface réellement branchée sur l’index Android utilisé par l’APK.

Version Android : 0.9.0 / versionCode 77.

Santé Connect, synchronisation LIVE, entraînement, hydratation et analyse des repas conservés.
