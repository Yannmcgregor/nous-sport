# Nous Sport V29.5

Correctif ciblé de V29.4 : l’Android WebView utilisait encore `fetch(`${url}/functions/v1/analyze-meal`)` alors que `url` n’existe pas dans l’adaptateur Android. V29.5 utilise directement `supabase.functions.invoke('analyze-meal', ...)`, avec l’envoi de l’image, du base64 et du MIME.
