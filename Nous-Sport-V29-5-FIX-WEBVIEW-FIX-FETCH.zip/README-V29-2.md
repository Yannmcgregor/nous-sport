# Nous Sport V29.2

Correction de l'analyse photo :
- l'app envoie aussi l'image en base64 brut + mimeType ;
- la fonction Supabase accepte Data URL et base64 brut ;
- V29.1 et la correction WebView sont conserves.
