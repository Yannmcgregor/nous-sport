# Nous Sport V26 - analyse des repas

1. Dans Supabase, ouvre Edge Functions et crée/déploie `analyze-meal` avec le fichier `supabase/functions/analyze-meal/index.ts`.
2. Dans les secrets de la fonction, ajoute `OPENAI_API_KEY` avec ta clé API OpenAI. Ne mets jamais cette clé dans l'application Android.
3. Optionnel : ajoute `OPENAI_MODEL=gpt-5.6-luna`. Sinon V26 utilise ce modèle par défaut.
4. Vérifie que `verify_jwt = false` pour cette fonction de prototype. Pour une version de production, remplacer ce mode public par une authentification Supabase utilisateur et ajouter une limitation de débit.
5. L'application V26 appelle ensuite `https://lykabwqpnjkuntnommpb.supabase.co/functions/v1/analyze-meal`.
