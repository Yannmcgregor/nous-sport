package com.noussport.app

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class PermissionsRationaleActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(TextView(this).apply {
            text = "Nous Sport utilise Santé Connect pour lire tes pas, calories actives, distance et fréquence cardiaque afin d'afficher tes statistiques sportives."
            textSize = 18f
            setPadding(48, 48, 48, 48)
        })
    }
}
