# Nous Sport V29.1

Correction ciblée de l'analyse photo des repas.

- L'application envoie maintenant l'image sous plusieurs noms compatibles avec les anciennes versions de la fonction Supabase.
- La fonction `analyze-meal` accepte `imageDataUrl`, `image`, `image_url` et `imageData`.
- La fonction renvoie un message explicite si aucune image valide n'est reçue.
- La correction V29 du WebView est conservée.
- Santé Connect, Supabase et les autres fonctions de V28 sont conservés.

IMPORTANT :
La fonction `supabase/functions/analyze-meal/index.ts` doit être déployée dans le projet Supabase pour remplacer l'ancienne fonction qui renvoie actuellement « Image manquante ».
