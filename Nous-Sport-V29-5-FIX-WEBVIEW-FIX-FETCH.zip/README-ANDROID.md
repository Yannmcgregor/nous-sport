Nous Sport V28

V26 conserve le mode local de l’application et connecte l’analyse photo des repas à la fonction Supabase analyze-meal via une session anonyme Supabase. V27 corrige aussi l’accès réseau du WebView chargé depuis file:// afin que l’appel HTTPS vers la fonction puisse réellement atteindre Supabase. V28 corrige une erreur JavaScript de l’adaptateur local lors d’un upsert, qui pouvait provoquer « rowsIn is not iterable » au démarrage.

Pré-requis Supabase : activer les connexions anonymes et déployer la fonction analyze-meal avec OPENAI_API_KEY configurée côté fonction.
