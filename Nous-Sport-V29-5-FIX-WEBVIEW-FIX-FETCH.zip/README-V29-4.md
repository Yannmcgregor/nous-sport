# Nous Sport V29.4

Correction de l’analyse photo des repas : l’adaptateur Android expose maintenant `supabase.auth.getSession()` en utilisant la session distante Supabase anonyme, et suppression d’une référence JavaScript à une variable `error` inexistante.

Le workflow V29.4 construit l’APK debug et publie l’artefact `NOUS-SPORT-V29-4-APK`.
