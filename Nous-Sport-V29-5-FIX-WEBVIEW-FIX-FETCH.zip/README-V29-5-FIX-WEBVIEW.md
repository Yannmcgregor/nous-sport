# Nous Sport V29.5 FIX WEBVIEW

Correctif ciblé pour l'erreur `Failed to fetch` lors de l'analyse photo du repas sur Android.

Le WebView ne charge plus la page principale depuis `file://`. Le HTML, CSS et JavaScript sont chargés depuis les assets puis affichés avec une origine HTTPS synthétique (`https://noussport.local/`). Cela permet à `fetch()` vers Supabase de suivre le comportement CORS normal du navigateur.

Aucune modification de la fonction Supabase `analyze-meal` n'est requise pour ce correctif.
