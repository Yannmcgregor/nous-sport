package com.noussport.app

import androidx.activity.ComponentActivity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.Instant

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var healthClient: HealthConnectClient? = null

    private val healthPermissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "NousSportHealth")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")

        initializeHealthConnectSafely()
    }

    private fun initializeHealthConnectSafely() {
        try {
            val status = HealthConnectClient.getSdkStatus(this)
            if (status == HealthConnectClient.SDK_AVAILABLE) {
                healthClient = HealthConnectClient.getOrCreate(this)
            }
        } catch (_: Throwable) {
            healthClient = null
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun isAvailable(): Boolean = healthClient != null

        @JavascriptInterface
        fun requestPermissions() {
            runOnUiThread {
                try {
                    val client = healthClient ?: return@runOnUiThread
                    permissionLauncher.launch(healthPermissions)
                } catch (_: Throwable) {
                }
            }
        }

        @JavascriptInterface
        fun readToday() {
            val client = healthClient ?: return
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val end = Instant.now()
                    val start = end.minusSeconds(24 * 60 * 60)
                    val range = TimeRangeFilter.between(start, end)

                    var steps = 0L
                    var calories = 0.0
                    var distance = 0.0
                    var heartRate = 0.0

                    try {
                        val r = client.readRecords(ReadRecordsRequest(StepsRecord::class, range))
                        steps = r.records.sumOf { it.count }
                    } catch (_: Throwable) {}

                    try {
                        val r = client.readRecords(ReadRecordsRequest(ActiveCaloriesBurnedRecord::class, range))
                        calories = r.records.sumOf { it.energy.inKilocalories }
                    } catch (_: Throwable) {}

                    try {
                        val r = client.readRecords(ReadRecordsRequest(DistanceRecord::class, range))
                        distance = r.records.sumOf { it.distance.inMeters }
                    } catch (_: Throwable) {}

                    try {
                        val r = client.readRecords(ReadRecordsRequest(HeartRateRecord::class, range))
                        val samples = r.records.flatMap { it.samples }
                        if (samples.isNotEmpty()) {
                            heartRate = samples.map { it.beatsPerMinute }.average()
                        }
                    } catch (_: Throwable) {}

                    val js = "window.onNousSportHealth && window.onNousSportHealth(${steps},${calories},${distance},${heartRate});"
                    runOnUiThread { web.evaluateJavascript(js, null) }
                } catch (_: Throwable) {
                }
            }
        }
    }

    private val permissionLauncher =
        registerForActivityResult(
            PermissionController.createRequestPermissionResultContract()
        ) { granted ->
            readHealthAfterPermission()
        }

    private fun readHealthAfterPermission() {
        web.postDelayed({ 
            web.evaluateJavascript("window.NousSportHealth && window.NousSportHealth.readToday();", null)
        }, 200)
    }
}
