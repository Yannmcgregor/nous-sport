# Nous Sport V16 - diagnostic natif

Version de diagnostic ultra-minimale.
- Aucun WebView
- Aucun Health Connect
- Aucune notification
- Aucun receiver/service
- Aucune dépendance AndroidX
- Une seule Activity Android native + TextView

But: déterminer si le crash se produit avant même le code de l'application.
Si V16 s'ouvre, la base Android et le package fonctionnent et on pourra réintroduire les composants un par un.
