package com.noussport.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.WHITE);
        root.setPadding(48, 48, 48, 48);

        TextView title = new TextView(this);
        title.setText("Nous Sport");
        title.setTextSize(32);
        title.setTextColor(Color.rgb(30, 30, 30));
        title.setGravity(Gravity.CENTER);

        TextView status = new TextView(this);
        status.setText("V16 TEST • démarrage Android OK");
        status.setTextSize(20);
        status.setTextColor(Color.rgb(60, 60, 60));
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 32, 0, 0);

        root.addView(title);
        root.addView(status);
        setContentView(root);
    }
}
