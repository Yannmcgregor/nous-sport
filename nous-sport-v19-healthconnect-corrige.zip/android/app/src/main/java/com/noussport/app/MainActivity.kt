package com.noussport.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.activity.ComponentActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.Instant

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var healthClient: HealthConnectClient? = null
    private var healthStatus = "Initialisation..."

    private val healthPermissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "NousSportHealth")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")

        initializeHealthConnect()
    }

    private fun showMessage(message: String) {
        healthStatus = message
        runOnUiThread {
            web.evaluateJavascript(
                "window.__healthError && window.__healthError(${jsString(message)});",
                null
            )
        }
    }

    private fun jsString(value: String): String =
        "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n") + "\""

    private fun initializeHealthConnect() {
        try {
            val status = HealthConnectClient.getSdkStatus(this)
            when (status) {
                HealthConnectClient.SDK_AVAILABLE -> {
                    healthClient = HealthConnectClient.getOrCreate(this)
                    showMessage("Santé Connect disponible. Appuie sur Connecter.")
                }
                HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> {
                    healthClient = null
                    showMessage("Santé Connect doit être mis à jour.")
                }
                else -> {
                    healthClient = null
                    showMessage("Santé Connect n'est pas disponible sur cet appareil.")
                }
            }
        } catch (e: Throwable) {
            healthClient = null
            showMessage("Erreur Santé Connect : ${e.javaClass.simpleName}")
        }
    }

    private fun openHealthConnectSettings() {
        try {
            startActivity(
                Intent("androidx.health.ACTION_HEALTH_CONNECT_SETTINGS")
            )
        } catch (_: Throwable) {
            try {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("market://details?id=com.google.android.apps.healthdata")
                    )
                )
            } catch (_: Throwable) {
                showMessage("Ouvre Santé Connect dans Paramètres Android.")
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun isAvailable(): Boolean = healthClient != null

        @JavascriptInterface
        fun requestPermissions() {
            runOnUiThread {
                try {
                    val client = healthClient
                    if (client == null) {
                        openHealthConnectSettings()
                        return@runOnUiThread
                    }
                    permissionLauncher.launch(healthPermissions)
                } catch (e: Throwable) {
                    showMessage("Impossible d'ouvrir les autorisations : ${e.javaClass.simpleName}")
                }
            }
        }

        @JavascriptInterface
        fun readToday() {
            val client = healthClient
            if (client == null) {
                showMessage(healthStatus)
                return
            }

            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val end = Instant.now()
                    val start = end.minusSeconds(24 * 60 * 60)
                    val range = TimeRangeFilter.between(start, end)

                    var steps = 0L
                    var calories = 0.0
                    var distance = 0.0
                    var heartRate = 0.0

                    try {
                        val r = client.readRecords(ReadRecordsRequest(StepsRecord::class, range))
                        steps = r.records.sumOf { it.count }
                    } catch (_: Throwable) {}

                    try {
                        val r = client.readRecords(ReadRecordsRequest(ActiveCaloriesBurnedRecord::class, range))
                        calories = r.records.sumOf { it.energy.inKilocalories }
                    } catch (_: Throwable) {}

                    try {
                        val r = client.readRecords(ReadRecordsRequest(DistanceRecord::class, range))
                        distance = r.records.sumOf { it.distance.inMeters }
                    } catch (_: Throwable) {}

                    try {
                        val r = client.readRecords(ReadRecordsRequest(HeartRateRecord::class, range))
                        val samples = r.records.flatMap { it.samples }
                        if (samples.isNotEmpty()) {
                            heartRate = samples.map { it.beatsPerMinute }.average()
                        }
                    } catch (_: Throwable) {}

                    val js =
                        "window.onNousSportHealth && window.onNousSportHealth($steps,$calories,$distance,$heartRate);"
                    runOnUiThread { web.evaluateJavascript(js, null) }
                } catch (e: Throwable) {
                    showMessage("Lecture Santé Connect : ${e.javaClass.simpleName}")
                }
            }
        }
    }

    private val permissionLauncher =
        registerForActivityResult(
            PermissionController.createRequestPermissionResultContract()
        ) { granted ->
            if (granted.containsAll(healthPermissions)) {
                showMessage("Autorisations Santé Connect accordées ✅")
                readHealthAfterPermission()
            } else {
                showMessage("Certaines autorisations Santé Connect ont été refusées.")
            }
        }

    private fun readHealthAfterPermission() {
        web.postDelayed({
            web.evaluateJavascript(
                "window.NousSportHealth && window.NousSportHealth.readToday();",
                null
            )
        }, 200)
    }
}
