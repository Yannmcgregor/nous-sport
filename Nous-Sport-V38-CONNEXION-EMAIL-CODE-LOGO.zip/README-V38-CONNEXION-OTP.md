# Nous Sport V38

Version 0.9.1 / versionCode 78.

- Interface visuelle historique de V34 conservée.
- Connexion réelle Supabase par e-mail + code OTP.
- Envoi du code par e-mail, validation à 6 chiffres.
- Session Supabase persistée dans le stockage local du WebView et rafraîchie avec le refresh token.
- Requêtes profiles/daily_activity/workouts/meals utilisent le JWT Supabase.
- Logo Android explicite via ic_launcher existant.
- Santé Connect et analyse de repas conservés.

Important : Supabase doit être configuré pour envoyer le Token dans le modèle d’e-mail OTP.
