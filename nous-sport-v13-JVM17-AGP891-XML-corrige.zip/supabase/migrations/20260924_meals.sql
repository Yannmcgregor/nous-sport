create table if not exists public.meals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  eaten_at timestamptz not null default now(),
  name text not null default 'Repas',
  calories integer not null check (calories >= 0),
  protein_g numeric(8,2),
  carbs_g numeric(8,2),
  fat_g numeric(8,2),
  items jsonb not null default '[]'::jsonb,
  confidence text,
  notes text
);

alter table public.meals enable row level security;

drop policy if exists "Users can read own meals" on public.meals;
create policy "Users can read own meals" on public.meals for select using (auth.uid() = user_id);

drop policy if exists "Users can insert own meals" on public.meals;
create policy "Users can insert own meals" on public.meals for insert with check (auth.uid() = user_id);

drop policy if exists "Users can update own meals" on public.meals;
create policy "Users can update own meals" on public.meals for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "Users can delete own meals" on public.meals;
create policy "Users can delete own meals" on public.meals for delete using (auth.uid() = user_id);
