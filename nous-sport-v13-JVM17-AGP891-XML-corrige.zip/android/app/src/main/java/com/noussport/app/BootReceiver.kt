package com.noussport.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (WaterReminderScheduler.isEnabled(context)) WaterReminderScheduler.scheduleNext(context)
    }
}
