package com.noussport.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object WaterReminderScheduler {
    const val CHANNEL_ID = "water_reminders"
    private const val PREFS = "nous_sport_water"
    private const val KEY_ENABLED = "enabled"
    private const val REQUEST_CODE = 2409

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

    fun enable(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, true).apply()
        scheduleNext(context)
    }

    fun disable(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, false).apply()
        val alarm = context.getSystemService(AlarmManager::class.java)
        alarm.cancel(pendingIntent(context))
    }

    fun scheduleNext(context: Context) {
        if (!isEnabled(context)) return
        val now = Calendar.getInstance()
        val next = Calendar.getInstance().apply {
            timeInMillis = now.timeInMillis
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val currentMinutes = next.get(Calendar.HOUR_OF_DAY) * 60 + next.get(Calendar.MINUTE)
        val reminderHours = intArrayOf(8, 10, 12, 14, 16, 18, 20)
        val nextHour = reminderHours.firstOrNull { it * 60 > currentMinutes }
        if (nextHour != null) {
            next.set(Calendar.HOUR_OF_DAY, nextHour)
            next.set(Calendar.MINUTE, 0)
        } else {
            next.add(Calendar.DAY_OF_YEAR, 1)
            next.set(Calendar.HOUR_OF_DAY, 8)
            next.set(Calendar.MINUTE, 0)
        }
        val alarm = context.getSystemService(AlarmManager::class.java)
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pendingIntent(context))
    }

    private fun pendingIntent(context: Context): PendingIntent = PendingIntent.getBroadcast(
        context,
        REQUEST_CODE,
        Intent(context, WaterReminderReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}
