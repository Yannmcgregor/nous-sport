Nous Sport V27

V26 conserve le mode local de l’application et connecte l’analyse photo des repas à la fonction Supabase analyze-meal via une session anonyme Supabase. V27 corrige aussi l’accès réseau du WebView chargé depuis file:// afin que l’appel HTTPS vers la fonction puisse réellement atteindre Supabase.

Pré-requis Supabase : activer les connexions anonymes et déployer la fonction analyze-meal avec OPENAI_API_KEY configurée côté fonction.
