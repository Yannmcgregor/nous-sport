package com.noussport.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.FileProvider
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.activity.ComponentActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var healthClient: HealthConnectClient? = null
    private var healthStatus = "Initialisation..."
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null

    private val healthPermissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(Color.WHITE)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        // V27: the app is loaded from file://android_asset. Allow the WebView
        // to make the authenticated HTTPS call to the Supabase Edge Function.
        // Without this, the browser-side fetch can fail before Supabase records
        // an invocation, which appears in JavaScript as "Failed to fetch".
        @Suppress("DEPRECATION")
        web.settings.allowFileAccessFromFileURLs = true
        @Suppress("DEPRECATION")
        web.settings.allowUniversalAccessFromFileURLs = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = object : WebViewClient() {
            override fun onReceivedError(view: WebView, errorCode: Int, description: String, failingUrl: String) {
                showNativeError("Erreur de chargement : $description")
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                if (message.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                    showNativeError("Erreur JavaScript ligne ${message.lineNumber()} : ${message.message()}")
                }
                return true
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.fileCallback?.onReceiveValue(null)
                this@MainActivity.fileCallback = filePathCallback
                val capture = fileChooserParams?.isCaptureEnabled == true
                if (capture) {
                    launchCamera()
                } else {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "image/*"
                    }
                    startActivityForResult(intent, REQUEST_GALLERY)
                }
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "NousSportHealth")
        setContentView(web)
        loadLocalPage()
        initializeHealthConnect()
    }

    private fun loadLocalPage() {
        try {
            // Keep the page and its relative JS/CSS files inside the APK assets.
            // Using loadDataWithBaseURL with an https origin makes relative assets
            // resolve to the network instead of android_asset, producing a blank page.
            web.loadUrl("file:///android_asset/index.html")
        } catch (e: Throwable) {
            showNativeError("Impossible de charger Nous Sport : ${e.javaClass.simpleName}")
        }
    }

    private fun showNativeError(message: String) {
        runOnUiThread {
            val safe = message.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            web.loadDataWithBaseURL(
                "https://noussport.local/",
                """<!doctype html><html><body style='font-family:sans-serif;padding:28px;background:#fff'><h2>Nous Sport</h2><p style='color:#b91c1c;font-weight:700'>Une erreur est survenue.</p><pre style='white-space:pre-wrap'>$safe</pre><button onclick='location.reload()' style='padding:12px 18px'>Réessayer</button></body></html>""",
                "text/html",
                "UTF-8",
                null
            )
        }
    }

    private fun launchCamera() {
        try {
            val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: filesDir
            val file = File.createTempFile("nous-sport-meal-", ".jpg", dir)
            cameraUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(MediaStore.EXTRA_OUTPUT, cameraUri)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivityForResult(intent, REQUEST_CAMERA)
        } catch (e: Throwable) {
            fileCallback?.onReceiveValue(null)
            fileCallback = null
            showNativeError("Impossible d'ouvrir la caméra : ${e.message ?: e.javaClass.simpleName}")
        }
    }

    @Deprecated("Deprecated in Android SDK, retained for WebView file chooser compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val callback = fileCallback ?: return
        val result = if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                REQUEST_CAMERA -> cameraUri?.let { arrayOf(it) }
                REQUEST_GALLERY -> data?.data?.let { arrayOf(it) }
                else -> null
            }
        } else null
        callback.onReceiveValue(result)
        fileCallback = null
        if (requestCode == REQUEST_CAMERA && resultCode != Activity.RESULT_OK) cameraUri = null
    }

    private fun showMessage(message: String) {
        healthStatus = message
        runOnUiThread {
            web.evaluateJavascript(
                "window.__healthError && window.__healthError(${jsString(message)});",
                null
            )
        }
    }

    private fun jsString(value: String): String =
        "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n") + "\""

    private fun initializeHealthConnect() {
        try {
            val status = HealthConnectClient.getSdkStatus(this)
            when (status) {
                HealthConnectClient.SDK_AVAILABLE -> {
                    healthClient = HealthConnectClient.getOrCreate(this)
                    showMessage("Santé Connect disponible. Appuie sur Connecter.")
                }
                HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> {
                    healthClient = null
                    showMessage("Santé Connect doit être mis à jour.")
                }
                else -> {
                    healthClient = null
                    showMessage("Santé Connect n'est pas disponible sur cet appareil.")
                }
            }
        } catch (e: Throwable) {
            healthClient = null
            showMessage("Erreur Santé Connect : ${e.javaClass.simpleName}")
        }
    }

    private fun openHealthConnectSettings() {
        try {
            val intent = if (android.os.Build.VERSION.SDK_INT >= 34) {
                Intent("android.health.connect.action.MANAGE_HEALTH_PERMISSIONS").apply {
                    putExtra(Intent.EXTRA_PACKAGE_NAME, packageName)
                }
            } else {
                Intent("androidx.health.ACTION_HEALTH_CONNECT_SETTINGS")
            }
            startActivity(intent)
        } catch (e: Throwable) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.apps.healthdata")))
            } catch (_: Throwable) {
                showMessage("Impossible d'ouvrir Santé Connect : ${e.javaClass.simpleName}")
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun isAvailable(): Boolean = healthClient != null

        @JavascriptInterface
        fun requestPermissions() {
            val client = healthClient
            if (client == null) {
                runOnUiThread { openHealthConnectSettings() }
                return
            }
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val granted = client.permissionController.getGrantedPermissions()
                    val missing = healthPermissions - granted
                    runOnUiThread {
                        try {
                            if (missing.isEmpty()) {
                                showMessage("Autorisations Santé Connect déjà accordées ✅")
                                readHealthAfterPermission()
                            } else permissionLauncher.launch(missing)
                        } catch (e: Throwable) {
                            showMessage("Ouverture des autorisations impossible : ${e.javaClass.simpleName}")
                            openHealthConnectSettings()
                        }
                    }
                } catch (e: Throwable) {
                    runOnUiThread {
                        showMessage("Vérification des autorisations impossible : ${e.javaClass.simpleName}")
                        openHealthConnectSettings()
                    }
                }
            }
        }

        @JavascriptInterface
        fun readToday() {
            val client = healthClient
            if (client == null) {
                showMessage(healthStatus)
                return
            }
            showMessage("Lecture Santé Connect…")
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    withTimeout(10_000L) {
                        val zone = ZoneId.systemDefault()
                        val start = LocalDate.now(zone).atStartOfDay(zone).toInstant()
                        val end = Instant.now()
                        val response = client.aggregate(
                            AggregateRequest(
                                metrics = setOf(
                                    StepsRecord.COUNT_TOTAL,
                                    ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL,
                                    DistanceRecord.DISTANCE_TOTAL,
                                    HeartRateRecord.BPM_AVG
                                ),
                                timeRangeFilter = TimeRangeFilter.between(start, end)
                            )
                        )
                        val steps = response[StepsRecord.COUNT_TOTAL] ?: 0L
                        val calories = response[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories ?: 0.0
                        val distanceMeters = response[DistanceRecord.DISTANCE_TOTAL]?.inMeters ?: 0.0
                        val heartRate = (response[HeartRateRecord.BPM_AVG] ?: 0L).toDouble()
                        val js = "window.__healthData && window.__healthData({steps:$steps,active_calories:${calories.toSafeNumber()},distance_km:${(distanceMeters / 1000.0).toSafeNumber()},avg_heart_rate:${heartRate.toSafeNumber()}});"
                        runOnUiThread {
                            healthStatus = "Santé Connect synchronisé ✅"
                            web.evaluateJavascript(js, null)
                        }
                    }
                } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
                    showMessage("Lecture Santé Connect trop longue (10 s). Vérifie les autorisations et réessaie.")
                } catch (e: Throwable) {
                    showMessage("Lecture Santé Connect impossible : ${e.javaClass.simpleName}${e.message?.let { " - $it" } ?: ""}")
                }
            }
        }
    }

    private fun Double.toSafeNumber(): String = if (isFinite()) toString() else "0"

    private val permissionLauncher = registerForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { granted ->
        if (granted.containsAll(healthPermissions)) {
            showMessage("Autorisations Santé Connect accordées ✅")
            readHealthAfterPermission()
        } else showMessage("Certaines autorisations Santé Connect ont été refusées.")
    }

    private fun readHealthAfterPermission() {
        web.postDelayed({ Bridge().readToday() }, 200)
    }

    companion object {
        private const val REQUEST_CAMERA = 2401
        private const val REQUEST_GALLERY = 2402
    }
}
