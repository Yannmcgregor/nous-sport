# Nous Sport V44

Connexion e-mail + mot de passe sans code OTP et sans étape de confirmation e-mail.

Important : dans Supabase, désactiver la confirmation obligatoire des e-mails (Authentication > Providers > Email > Confirm email désactivé, selon l’interface du projet).

L’application tente une connexion automatique après la création du compte. Les adresses e-mail restent mémorisées dans la liste déroulante, mais les mots de passe ne sont pas enregistrés.
