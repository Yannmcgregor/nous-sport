# Nous Sport V42

Dernière évolution de l’authentification.

- Pas de code OTP.
- Créer un compte avec adresse e-mail + mot de passe.
- Supabase envoie l’e-mail de confirmation lorsque la confirmation e-mail est activée.
- Après confirmation, connexion avec adresse e-mail + mot de passe.
- Les adresses e-mail utilisées sont mémorisées localement et proposées dans une liste déroulante dans le champ e-mail.
- La session reste mémorisée sur l’appareil.
- Ancienne interface conservée.
- Santé Connect, analyse des repas, hydratation et reste des fonctions conservés.
- Version Android : 0.9.6 / versionCode 83.

Important : dans Supabase, l’option de confirmation des e-mails doit être activée pour que la création de compte déclenche l’e-mail de confirmation.
