# Nous Sport V43

Version Android avec authentification classique par e-mail + mot de passe.

- Aucun code OTP.
- Créer un compte : e-mail + mot de passe, puis e-mail de confirmation Supabase.
- Se connecter : e-mail + mot de passe après confirmation.
- Les adresses e-mail utilisées sont mémorisées localement et proposées dans une liste déroulante/suggestions dans le champ e-mail.
- La session Supabase reste mémorisée avec renouvellement via refresh token.
- Ancienne interface conservée.
- Santé Connect, hydratation, analyse des repas et autres fonctions conservées.
- main.yml n'est pas modifié.
