/* NOUS SPORT V53: read steps specifically from Samsung Health */
package com.noussport.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import android.webkit.WebResourceResponse
import androidx.core.content.FileProvider
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.metadata.DataOrigin
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.activity.ComponentActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var healthClient: HealthConnectClient? = null
    private var healthStatus = "Initialisation..."
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null

    private val healthPermissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(Color.WHITE)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        // Serve the bundled page with an HTTPS base origin instead of file://.
        // Android WebView can otherwise reject cross-origin fetches to Supabase
        // before the request reaches the Edge Function, surfacing as "Failed to fetch".
        web.settings.mediaPlaybackRequiresUserGesture = false

        // Serve the bundled HTML from a real local HTTPS origin. This avoids
        // synthetic-host DNS errors (ERR_NAME_NOT_RESOLVED) while preserving
        // localStorage/session persistence and allowing normal HTTPS fetches
        // to Supabase.
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: android.webkit.WebResourceRequest?): WebResourceResponse? {
                val url = request?.url ?: return super.shouldInterceptRequest(view, request)
                if (url.toString() == "https://appassets.androidplatform.net/assets/fireworks.mp4") {
                    return try { WebResourceResponse("video/mp4", "binary", assets.open("fireworks.mp4")) } catch (_: Throwable) { null }
                }
                return assetLoader.shouldInterceptRequest(url)
                    ?: super.shouldInterceptRequest(view, request)
            }
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                // V34 safety net: guarantee the Pause control exists and is wired in the Android WebView.
                view.evaluateJavascript("""(function(){
                    try {
                        var controls=document.querySelector('.workout-controls');
                        var pause=document.getElementById('togglePauseWorkout');
                        var stop=document.getElementById('stopWorkout');
                        if(controls && !pause){
                            pause=document.createElement('button');
                            pause.id='togglePauseWorkout';
                            pause.className='pause-workout';
                            pause.textContent='⏸ Mettre en pause';
                            controls.insertBefore(pause, stop || null);
                        }
                        if(pause && typeof window.pauseWorkout==='function'){pause.onclick=window.pauseWorkout;}
                        var quit=document.getElementById('quitCompletion');
                        if(quit && typeof window.showCompletion==='function'){quit.onclick=function(){var v=document.getElementById('fireworksVideo');try{v.pause();v.currentTime=0;}catch(e){}var o=document.getElementById('completionOverlay');if(o)o.classList.add('hidden');if(typeof window.load==='function')window.load();};}
                    }catch(e){}
                })();""", null)
            }

            override fun onReceivedError(
                view: WebView,
                request: android.webkit.WebResourceRequest,
                error: android.webkit.WebResourceError
            ) {
                if (request.isForMainFrame) {
                    showNativeError("Erreur de chargement : ${error.description}")
                }
            }

            @Suppress("DEPRECATION")
            override fun onReceivedError(
                view: WebView,
                errorCode: Int,
                description: String,
                failingUrl: String
            ) {
                if (failingUrl.startsWith("file:///android_asset/")) {
                    showNativeError("Erreur de chargement : $description")
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                if (message.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                    showNativeError("Erreur JavaScript ligne ${message.lineNumber()} : ${message.message()}")
                }
                return true
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.fileCallback?.onReceiveValue(null)
                this@MainActivity.fileCallback = filePathCallback
                val capture = fileChooserParams?.isCaptureEnabled == true
                if (capture) {
                    launchCamera()
                } else {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "image/*"
                    }
                    startActivityForResult(intent, REQUEST_GALLERY)
                }
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "NousSportHealth")
        setContentView(web)
        loadLocalPage()
        initializeHealthConnect()
    }

    private fun loadLocalPage() {
        try {
            // Inject the bundled HTML directly while keeping a stable HTTPS base
            // origin. This avoids making the WebView navigate to the synthetic
            // appassets host for the main document, while relative assets still
            // go through WebViewAssetLoader and localStorage remains available.
            val html = assets.open("index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
            web.loadDataWithBaseURL(
                "https://appassets.androidplatform.net/assets/",
                html,
                "text/html",
                "UTF-8",
                "https://appassets.androidplatform.net/assets/index.html"
            )
        } catch (e: Throwable) {
            showNativeError("Impossible de charger Nous Sport : ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun showNativeError(message: String) {
        runOnUiThread {
            val safe = message.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            web.loadDataWithBaseURL(
                "https://appassets.androidplatform.net/assets/",
                """<!doctype html><html><body style='font-family:sans-serif;padding:28px;background:#fff'><h2>Nous Sport</h2><p style='color:#b91c1c;font-weight:700'>Une erreur est survenue.</p><pre style='white-space:pre-wrap'>$safe</pre><button onclick='location.reload()' style='padding:12px 18px'>Réessayer</button></body></html>""",
                "text/html",
                "UTF-8",
                null
            )
        }
    }

    private fun launchCamera() {
        try {
            val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: filesDir
            val file = File.createTempFile("nous-sport-meal-", ".jpg", dir)
            cameraUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(MediaStore.EXTRA_OUTPUT, cameraUri)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivityForResult(intent, REQUEST_CAMERA)
        } catch (e: Throwable) {
            fileCallback?.onReceiveValue(null)
            fileCallback = null
            showNativeError("Impossible d'ouvrir la caméra : ${e.message ?: e.javaClass.simpleName}")
        }
    }

    @Deprecated("Deprecated in Android SDK, retained for WebView file chooser compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val callback = fileCallback ?: return
        val result = if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                REQUEST_CAMERA -> cameraUri?.let { arrayOf(it) }
                REQUEST_GALLERY -> data?.data?.let { arrayOf(it) }
                else -> null
            }
        } else null
        callback.onReceiveValue(result)
        fileCallback = null
        if (requestCode == REQUEST_CAMERA && resultCode != Activity.RESULT_OK) cameraUri = null
    }

    private fun showMessage(message: String) {
        healthStatus = message
        runOnUiThread {
            web.evaluateJavascript(
                "window.__healthError && window.__healthError(${jsString(message)});",
                null
            )
        }
    }

    private fun jsString(value: String): String =
        "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n") + "\""

    private fun initializeHealthConnect() {
        try {
            val status = HealthConnectClient.getSdkStatus(this)
            when (status) {
                HealthConnectClient.SDK_AVAILABLE -> {
                    healthClient = HealthConnectClient.getOrCreate(this)
                    showMessage("Santé Connect disponible. Appuie sur Connecter.")
                }
                HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> {
                    healthClient = null
                    showMessage("Santé Connect doit être mis à jour.")
                }
                else -> {
                    healthClient = null
                    showMessage("Santé Connect n'est pas disponible sur cet appareil.")
                }
            }
        } catch (e: Throwable) {
            healthClient = null
            showMessage("Erreur Santé Connect : ${e.javaClass.simpleName}")
        }
    }

    private fun openHealthConnectSettings() {
        try {
            val intent = if (android.os.Build.VERSION.SDK_INT >= 34) {
                Intent("android.health.connect.action.MANAGE_HEALTH_PERMISSIONS").apply {
                    putExtra(Intent.EXTRA_PACKAGE_NAME, packageName)
                }
            } else {
                Intent("androidx.health.ACTION_HEALTH_CONNECT_SETTINGS")
            }
            startActivity(intent)
        } catch (e: Throwable) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.apps.healthdata")))
            } catch (_: Throwable) {
                showMessage("Impossible d'ouvrir Santé Connect : ${e.javaClass.simpleName}")
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun isAvailable(): Boolean = healthClient != null

        @JavascriptInterface
        fun requestPermissions() {
            val client = healthClient
            if (client == null) {
                runOnUiThread { openHealthConnectSettings() }
                return
            }
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val granted = client.permissionController.getGrantedPermissions()
                    val missing = healthPermissions - granted
                    runOnUiThread {
                        try {
                            if (missing.isEmpty()) {
                                showMessage("Autorisations Santé Connect déjà accordées ✅")
                                readHealthAfterPermission()
                            } else permissionLauncher.launch(missing)
                        } catch (e: Throwable) {
                            showMessage("Ouverture des autorisations impossible : ${e.javaClass.simpleName}")
                            openHealthConnectSettings()
                        }
                    }
                } catch (e: Throwable) {
                    runOnUiThread {
                        showMessage("Vérification des autorisations impossible : ${e.javaClass.simpleName}")
                        openHealthConnectSettings()
                    }
                }
            }
        }

        @JavascriptInterface
        fun readToday() {
            val client = healthClient
            if (client == null) {
                showMessage(healthStatus)
                return
            }
            showMessage("Lecture Santé Connect…")
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    withTimeout(10_000L) {
                        val zone = ZoneId.systemDefault()
                        val start = LocalDate.now(zone).atStartOfDay(zone).toInstant()
                        val end = Instant.now()
                        // Steps are cumulative. Health Connect recommends COUNT_TOTAL aggregation to avoid double-counting.
                        // Keep the range from local midnight through the current instant so the dashboard is truly today's total without summing raw records from multiple sources.
                        val granted = client.permissionController.getGrantedPermissions()

                        val stepsPermission = HealthPermission.getReadPermission(StepsRecord::class)
                        val caloriesPermission = HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class)
                        val distancePermission = HealthPermission.getReadPermission(DistanceRecord::class)
                        val heartPermission = HealthPermission.getReadPermission(HeartRateRecord::class)

                        if (!granted.contains(stepsPermission) &&
                            !granted.contains(caloriesPermission) &&
                            !granted.contains(distancePermission) &&
                            !granted.contains(heartPermission)
                        ) {
                            showMessage("Aucune autorisation Santé Connect accordée.")
                            return@withTimeout
                        }

                        var steps = 0L
                        var calories = 0.0
                        var distanceMeters = 0.0
                        var heartRate = 0.0
                        val errors = mutableListOf<String>()

                        if (granted.contains(stepsPermission)) {
                            try {
                                val r = client.aggregate(
                                    AggregateRequest(
                                        metrics = setOf(StepsRecord.COUNT_TOTAL),
                                        timeRangeFilter = TimeRangeFilter.between(start, end),
                                        dataOriginFilter = setOf(DataOrigin("com.sec.android.app.shealth"))
                                    )
                                )
                                steps = r[StepsRecord.COUNT_TOTAL] ?: 0L
                            } catch (e: Throwable) {
                                errors.add("pas: ${e.javaClass.simpleName}")
                            }
                        }

                        if (granted.contains(caloriesPermission)) {
                            try {
                                val r = client.aggregate(
                                    AggregateRequest(
                                        metrics = setOf(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL),
                                        timeRangeFilter = TimeRangeFilter.between(start, end)
                                    )
                                )
                                calories = r[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories ?: 0.0
                            } catch (e: Throwable) {
                                errors.add("calories: ${e.javaClass.simpleName}")
                            }
                        }

                        if (granted.contains(distancePermission)) {
                            try {
                                val r = client.aggregate(
                                    AggregateRequest(
                                        metrics = setOf(DistanceRecord.DISTANCE_TOTAL),
                                        timeRangeFilter = TimeRangeFilter.between(start, end)
                                    )
                                )
                                distanceMeters = r[DistanceRecord.DISTANCE_TOTAL]?.inMeters ?: 0.0
                            } catch (e: Throwable) {
                                errors.add("distance: ${e.javaClass.simpleName}")
                            }
                        }

                        if (granted.contains(heartPermission)) {
                            try {
                                val r = client.aggregate(
                                    AggregateRequest(
                                        metrics = setOf(HeartRateRecord.BPM_AVG),
                                        timeRangeFilter = TimeRangeFilter.between(start, end)
                                    )
                                )
                                heartRate = (r[HeartRateRecord.BPM_AVG] ?: 0L).toDouble()
                            } catch (e: Throwable) {
                                errors.add("fréquence: ${e.javaClass.simpleName}")
                            }
                        }

                        val js = "window.__healthData && window.__healthData({steps:$steps,active_calories:${calories.toSafeNumber()},distance_km:${(distanceMeters / 1000.0).toSafeNumber()},avg_heart_rate:${heartRate.toSafeNumber()}});"
                        val status = if (errors.isEmpty()) {
                            "Santé Connect synchronisé ✅"
                        } else {
                            "Santé Connect synchronisé avec avertissement : ${errors.joinToString(", ")}"
                        }
                        runOnUiThread {
                            healthStatus = status
                            web.evaluateJavascript(js, null)
                        }
                    }
                } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
                    showMessage("Lecture Santé Connect trop longue (10 s). Vérifie les autorisations et réessaie.")
                } catch (e: Throwable) {
                    showMessage("Lecture Santé Connect impossible : ${e.javaClass.simpleName}${e.message?.let { " - $it" } ?: ""}")
                }
            }
        }
    }

    private fun Double.toSafeNumber(): String = if (isFinite()) toString() else "0"

    private val permissionLauncher = registerForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { granted ->
        if (granted.containsAll(healthPermissions)) {
            showMessage("Autorisations Santé Connect accordées ✅")
            readHealthAfterPermission()
        } else showMessage("Certaines autorisations Santé Connect ont été refusées.")
    }

    private fun readHealthAfterPermission() {
        web.postDelayed({ Bridge().readToday() }, 200)
    }

    companion object {
        private const val REQUEST_CAMERA = 2401
        private const val REQUEST_GALLERY = 2402
    }
}
