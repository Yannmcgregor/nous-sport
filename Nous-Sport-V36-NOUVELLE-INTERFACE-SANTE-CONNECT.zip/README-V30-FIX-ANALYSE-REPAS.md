# Nous Sport V30 - correctif analyse photo

Le problème de cette version est ciblé sur la fonction Supabase `analyze-meal`.

## Correction
- `supabase/config.toml` garde `verify_jwt = false`.
- `supabase/functions/analyze-meal/index.ts` n'utilise plus `withSupabase({ auth: 'user' })`.
- La fonction répond directement aux requêtes `OPTIONS` CORS puis aux requêtes POST.
- L'appel Android reste direct vers `/functions/v1/analyze-meal`.
- Le message d'erreur Android donne maintenant le type réel de l'erreur réseau.

## À faire avant de reconstruire l'APK
1. Dans Supabase, ouvre Edge Functions > `analyze-meal`.
2. Remplace le code de la fonction par le fichier `supabase/functions/analyze-meal/index.ts` de cette archive.
3. Vérifie que le secret `OPENAI_API_KEY` est toujours configuré.
4. Déploie/enregistre la fonction.
5. Ensuite seulement, reconstruis l'APK avec cette archive.

Cette correction ne change pas l'interface, Santé Connect, les séances, les calories ou les données locales.
