# Nous Sport V36

Nouvelle interface sportive sombre et moderne.

- Tableau de bord modernisé
- Objectifs en grille 2 x 2
- Pas, calories restantes, calories brûlées et hydratation
- Santé Connect conservé
- Analyse photo des repas conservée
- Entraînement, pause, LIVE 5 secondes, encouragement et fin de séance conservés
- Version Android 0.8.0 / versionCode 76

`main.yml` n’est pas modifié par cette version.
