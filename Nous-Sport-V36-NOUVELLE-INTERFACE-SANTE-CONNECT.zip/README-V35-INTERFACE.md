# Nous Sport V35 – nouvelle interface

V35 conserve les fonctions de V34 Santé Connect et améliore uniquement l'interface visuelle.

Modifications principales :
- tableau de bord sportif sombre et moderne ;
- cartes et boutons redessinés ;
- quatre anneaux mieux intégrés (pas, calories à manger, calories brûlées, eau) ;
- affichage plus compact et adapté au téléphone ;
- écran entraînement modernisé ;
- écran connexion modernisé ;
- analyse photo des repas conservée ;
- Santé Connect conservé sans changement de logique ;
- rappels d'hydratation conservés ;
- statistiques conservées ;
- pause, flash vert, vidéo de fin et félicitations conservés.

Version Android : 0.7.0 (versionCode 75).
