# Nous Sport V36

Refonte visuelle de l'accueil Android.

- Nouveau tableau de bord sombre et sportif
- Statistiques rapides
- Anneaux d'objectifs en grille 2x2 sur téléphone
- Hydratation et rappels
- Entraînement et Santé Connect conservés
- Analyse photo des repas conservée
- Version Android : 0.8.0
- versionCode : 76

La logique Santé Connect de V34/V35 n'est pas modifiée.
