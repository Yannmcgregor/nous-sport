# Nous Sport V33

Modifications :
- Pause / reprise pendant une séance.
- Le chronomètre exclut le temps passé en pause.
- Les pas, calories et distance accumulés pendant une pause ne sont pas ajoutés à la séance.
- Fin de séance : applaudissements pendant 5 secondes.
- Fin de séance : vidéo de feux d'artifice de 5 secondes en arrière-plan.
- Phrase de félicitations à la fin de la séance.
- La page de fin reste affichée jusqu'au bouton « ✓ Quitter ».
- Conservation de l'analyse photo du repas et du correctif image V32.
- Nouveau workflow GitHub : `Build Nous Sport V33 PAUSE FEUX CALORIES`.
