# Nous Sport V31 - correction URL Supabase

Correction uniquement de l'URL Supabase utilisée par l'application.

Ancienne URL : https://lykabwqpnjkuntnommpb.supabase.co
Nouvelle URL : https://lykabwqpnjkuntnonmpb.supabase.co

Aucune clé API ni autre fonctionnalité n'a été modifiée.
