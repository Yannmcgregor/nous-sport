# Nous Sport V34 - correctif Santé Connect

Correctif Android version 0.6.1.

La lecture Santé Connect ne dépend plus d'une seule requête contenant les quatre types de données.
L'application vérifie les autorisations réellement accordées et lit séparément les pas, calories actives,
distance et fréquence cardiaque. Ainsi, une autorisation manquante ou une erreur sur une métrique ne bloque
plus les autres données.

Le reste du projet V34 est conservé, notamment pause/reprise de séance, LIVE 5 secondes, hydratation,
analyse photo des repas et écran de félicitations.
