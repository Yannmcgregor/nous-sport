package com.noussport.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.activity.ComponentActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var healthClient: HealthConnectClient? = null
    private var healthStatus = "Initialisation..."

    private val healthPermissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "NousSportHealth")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")

        initializeHealthConnect()
    }

    private fun showMessage(message: String) {
        healthStatus = message
        runOnUiThread {
            web.evaluateJavascript(
                "window.__healthError && window.__healthError(${jsString(message)});",
                null
            )
        }
    }

    private fun jsString(value: String): String =
        "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n") + "\""

    private fun initializeHealthConnect() {
        try {
            val status = HealthConnectClient.getSdkStatus(this)
            when (status) {
                HealthConnectClient.SDK_AVAILABLE -> {
                    healthClient = HealthConnectClient.getOrCreate(this)
                    showMessage("Santé Connect disponible. Appuie sur Connecter.")
                }
                HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> {
                    healthClient = null
                    showMessage("Santé Connect doit être mis à jour.")
                }
                else -> {
                    healthClient = null
                    showMessage("Santé Connect n'est pas disponible sur cet appareil.")
                }
            }
        } catch (e: Throwable) {
            healthClient = null
            showMessage("Erreur Santé Connect : ${e.javaClass.simpleName}")
        }
    }

    private fun openHealthConnectSettings() {
        try {
            val intent = if (android.os.Build.VERSION.SDK_INT >= 34) {
                Intent("android.health.connect.action.MANAGE_HEALTH_PERMISSIONS").apply {
                    putExtra(Intent.EXTRA_PACKAGE_NAME, packageName)
                }
            } else {
                Intent("androidx.health.ACTION_HEALTH_CONNECT_SETTINGS")
            }
            startActivity(intent)
        } catch (e: Throwable) {
            try {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("market://details?id=com.google.android.apps.healthdata")
                    )
                )
            } catch (_: Throwable) {
                showMessage("Impossible d'ouvrir Santé Connect : ${e.javaClass.simpleName}")
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun isAvailable(): Boolean = healthClient != null

        @JavascriptInterface
        fun requestPermissions() {
            val client = healthClient
            if (client == null) {
                runOnUiThread { openHealthConnectSettings() }
                return
            }

            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val granted = client.permissionController.getGrantedPermissions()
                    val missing = healthPermissions - granted

                    runOnUiThread {
                        try {
                            if (missing.isEmpty()) {
                                showMessage("Autorisations Santé Connect déjà accordées ✅")
                                readHealthAfterPermission()
                            } else {
                                permissionLauncher.launch(missing)
                            }
                        } catch (e: Throwable) {
                            showMessage("Ouverture des autorisations impossible : ${e.javaClass.simpleName}")
                            openHealthConnectSettings()
                        }
                    }
                } catch (e: Throwable) {
                    runOnUiThread {
                        showMessage("Vérification des autorisations impossible : ${e.javaClass.simpleName}")
                        openHealthConnectSettings()
                    }
                }
            }
        }

        @JavascriptInterface
        fun readToday() {
            val client = healthClient
            if (client == null) {
                showMessage(healthStatus)
                return
            }

            showMessage("Lecture Santé Connect…")

            CoroutineScope(Dispatchers.IO).launch {
                try {
                    withTimeout(10_000L) {
                        val zone = ZoneId.systemDefault()
                        val start = LocalDate.now(zone).atStartOfDay(zone).toInstant()
                        val end = Instant.now()
                        val range = TimeRangeFilter.between(start, end)

                        val response = client.aggregate(
                            AggregateRequest(
                                metrics = setOf(
                                    StepsRecord.COUNT_TOTAL,
                                    ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL,
                                    DistanceRecord.DISTANCE_TOTAL,
                                    HeartRateRecord.BPM_AVG
                                ),
                                timeRangeFilter = range
                            )
                        )

                        val steps = response[StepsRecord.COUNT_TOTAL] ?: 0L
                        val calories = response[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]
                            ?.inKilocalories ?: 0.0
                        val distanceMeters = response[DistanceRecord.DISTANCE_TOTAL]
                            ?.inMeters ?: 0.0
                        val heartRate = (response[HeartRateRecord.BPM_AVG] ?: 0L).toDouble()

                        val js = "window.__healthData && window.__healthData({steps:$steps,active_calories:${calories.toSafeNumber()},distance_km:${(distanceMeters / 1000.0).toSafeNumber()},avg_heart_rate:${heartRate.toSafeNumber()}});"
                        runOnUiThread {
                            healthStatus = "Santé Connect synchronisé ✅"
                            web.evaluateJavascript(js, null)
                        }
                    }
                } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
                    showMessage("Lecture Santé Connect trop longue (10 s). Vérifie les autorisations et réessaie.")
                } catch (e: Throwable) {
                    showMessage("Lecture Santé Connect impossible : ${e.javaClass.simpleName}${e.message?.let { " - $it" } ?: ""}")
                }
            }
        }

    }

    private fun Double.toSafeNumber(): String =
        if (isFinite()) toString() else "0"

    private val permissionLauncher =
        registerForActivityResult(
            PermissionController.createRequestPermissionResultContract()
        ) { granted ->
            if (granted.containsAll(healthPermissions)) {
                showMessage("Autorisations Santé Connect accordées ✅")
                readHealthAfterPermission()
            } else {
                showMessage("Certaines autorisations Santé Connect ont été refusées.")
            }
        }

    private fun readHealthAfterPermission() {
        web.postDelayed({
            Bridge().readToday()
        }, 200)
    }
}
