# Nous Sport V15 - démarrage stable

Cette version isole le démarrage Android :
- Activity Android native minimale
- WebView local avec JavaScript + stockage local
- aucune initialisation Santé Connect au démarrage
- aucune notification ou alarme au démarrage
- aucune dépendance AppCompat
- interface Nous Sport conservée

Objectif : vérifier que l'APK s'ouvre correctement. Santé Connect sera réintégré après validation du démarrage.
