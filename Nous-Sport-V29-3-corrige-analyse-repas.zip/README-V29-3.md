# Nous Sport V29.3

Correction de l’analyse photo des repas.

- L’application utilise maintenant un appel HTTP direct vers l’Edge Function `analyze-meal` avec `Content-Type: application/json`, la clé publishable et le jeton de session Supabase.
- L’image est envoyée explicitement comme Data URL, Base64 et MIME type.
- Le bundle Android `assets/src/main.js` est mis à jour en même temps que `src/main.js`.
- Les fonctions Health Connect, hydratation, séances et tableau de bord sont conservées.
