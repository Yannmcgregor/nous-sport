# Nous Sport V31 - analyse repas via Android natif

V30 a confirmé que la fonction Supabase est déployée mais l'appel depuis le WebView retourne toujours `Failed to fetch`. V31 contourne complètement le réseau du WebView pour cette fonction.

## Correction
- Le bouton Analyse photo appelle désormais un pont Android natif.
- Android fait directement le POST HTTPS vers `analyze-meal`.
- Le résultat revient dans la page WebView via JavaScript.
- Santé Connect et le reste de l'application sont conservés.

Aucune modification supplémentaire de Supabase n'est nécessaire pour ce correctif.
