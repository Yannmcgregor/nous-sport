/* Nous Sport V29.5 FIX FETCH: direct Edge Function call, no Auth bootstrap.
   Nous Sport V27: self-contained Android WebView runtime.
   V13 loaded the Vite source directly from file://, so import/@supabase and import.meta.env
   caused the WebView to fail before the first screen could render.
   This adapter keeps the app usable offline and persists account/profile/activity locally.
   Supabase can be wired back later without changing the Android bridge. */
function makeLocalSupabase(){
  const SUPABASE_URL='https://lykabwqpnjkuntnonmpb.supabase.co';
  const SUPABASE_KEY='sb_publishable_OWHGIQAwfKH83v4M5QQMTQ_vgj_pSpt';
  const SESSION_KEY='noussport-supabase-session-v38';
  let session=null;
  try{session=JSON.parse(localStorage.getItem(SESSION_KEY)||'null')}catch(e){session=null}
  const clone=v=>v==null?v:JSON.parse(JSON.stringify(v));
  const saveSession=s=>{session=s||null;if(s)localStorage.setItem(SESSION_KEY,JSON.stringify(s));else localStorage.removeItem(SESSION_KEY)};
  const apiFetch=async(path,options={})=>{
    const headers={apikey:SUPABASE_KEY,'Content-Type':'application/json',...(options.headers||{})};
    if(session?.access_token)headers.Authorization='Bearer '+session.access_token;
    let res=await fetch(SUPABASE_URL+path,{...options,headers});
    if(res.status===401 && session?.refresh_token){
      const rr=await fetch(SUPABASE_URL+'/auth/v1/token?grant_type=refresh_token',{method:'POST',headers:{apikey:SUPABASE_KEY,'Content-Type':'application/json'},body:JSON.stringify({refresh_token:session.refresh_token})});
      const raw=await rr.text();let data={};try{data=JSON.parse(raw)}catch(e){}
      if(rr.ok&&data.access_token){saveSession(data);headers.Authorization='Bearer '+data.access_token;res=await fetch(SUPABASE_URL+path,{...options,headers})}else{saveSession(null)}
    }
    return res;
  };
  const readJson=async res=>{const raw=await res.text();let data=null;try{data=raw?JSON.parse(raw):null}catch(e){data=raw}return data};
  const auth={
    async signUp({email,password}){const res=await fetch(SUPABASE_URL+'/auth/v1/signup',{method:'POST',headers:{apikey:SUPABASE_KEY,'Content-Type':'application/json'},body:JSON.stringify({email,password})});const data=await readJson(res);if(!res.ok)return{data:null,error:{message:data?.msg||data?.message||data?.error_description||'Impossible de créer le compte.'}};if(data?.access_token)saveSession(data);return{data,error:null}},
    async signInWithPassword({email,password}){const res=await fetch(SUPABASE_URL+'/auth/v1/token?grant_type=password',{method:'POST',headers:{apikey:SUPABASE_KEY,'Content-Type':'application/json'},body:JSON.stringify({email,password})});const data=await readJson(res);if(!res.ok||!data?.access_token)return{data:null,error:{message:data?.msg||data?.message||data?.error_description||'E-mail ou mot de passe incorrect. Si tu viens de créer le compte, confirme d’abord ton e-mail.'}};saveSession(data);return{data,error:null}},
    async getSession(){if(!session?.access_token)return{data:{session:null},error:null};if(session.expires_at&&Date.now()/1000>Number(session.expires_at)-60){if(session.refresh_token){const res=await fetch(SUPABASE_URL+'/auth/v1/token?grant_type=refresh_token',{method:'POST',headers:{apikey:SUPABASE_KEY,'Content-Type':'application/json'},body:JSON.stringify({refresh_token:session.refresh_token})});const data=await readJson(res);if(res.ok&&data?.access_token){saveSession(data)}else{saveSession(null)}}}return{data:{session},error:null}},
    async getUser(){const s=await this.getSession();if(!s.data.session?.access_token)return{data:{user:null},error:null};const res=await apiFetch('/auth/v1/user');const data=await readJson(res);if(!res.ok)return{data:{user:null},error:{message:data?.message||'Session expirée.'}};return{data:{user:data},error:null}},
    async signOut(){if(session?.access_token){try{await apiFetch('/auth/v1/logout',{method:'POST'})}catch(e){}}saveSession(null);return{error:null}},
    onAuthStateChange(){return{data:{subscription:{unsubscribe(){}}}}}
  };
  const builder=(table,action='select',payload=null)=>{
    let filters=[],orderBy=null,ascending=true,limitN=null,singleMode=false,maybeSingleMode=false;
    const api={select(cols='*'){action='select';api._cols=cols;return api},insert(row){action='insert';payload=Array.isArray(row)?row:[row];return api},update(row){action='update';payload=row;return api},upsert(row,opts={}){action='upsert';payload=Array.isArray(row)?row:[row];api._upsertOpts=opts;return api},eq(k,v){filters.push([k,'eq',v]);return api},gte(k,v){filters.push([k,'gte',v]);return api},lte(k,v){filters.push([k,'lte',v]);return api},lt(k,v){filters.push([k,'lt',v]);return api},order(k,opts={}){orderBy=k;ascending=opts.ascending!==false;return api},limit(n){limitN=n;return api},single(){singleMode=true;return api},maybeSingle(){maybeSingleMode=true;return api},then(resolve,reject){return Promise.resolve(run()).then(resolve,reject)}};
    async function run(){
      if(action==='select'){
        const params=new URLSearchParams();params.set('select',api._cols||'*');
        for(const [k,op,v] of filters){params.set(k,op+'.'+String(v))}
        if(orderBy)params.set('order',orderBy+'.'+(ascending?'asc':'desc'));if(limitN!=null)params.set('limit',String(limitN));
        const res=await apiFetch('/rest/v1/'+encodeURIComponent(table)+'?'+params.toString());const data=await readJson(res);if(!res.ok)return{data:null,error:{message:data?.message||data?.details||`Erreur Supabase (${res.status})`}};
        if(singleMode)return{data:Array.isArray(data)?(data[0]||null):data,error:Array.isArray(data)&&!data.length?{message:'Aucune ligne'}:null};if(maybeSingleMode)return{data:Array.isArray(data)?(data[0]||null):data,error:null};return{data:Array.isArray(data)?data:[],error:null};
      }
      if(action==='insert'){
        const res=await apiFetch('/rest/v1/'+encodeURIComponent(table),{method:'POST',headers:{Prefer:'return=representation'},body:JSON.stringify(payload)});const data=await readJson(res);return res.ok?{data,error:null}:{data:null,error:{message:data?.message||data?.details||`Erreur Supabase (${res.status})`}};
      }
      if(action==='update'){
        const params=new URLSearchParams();for(const [k,op,v] of filters)params.set(k,op+'.'+String(v));
        const res=await apiFetch('/rest/v1/'+encodeURIComponent(table)+'?'+params.toString(),{method:'PATCH',headers:{Prefer:'return=representation'},body:JSON.stringify(payload)});const data=await readJson(res);return res.ok?{data,error:null}:{data:null,error:{message:data?.message||data?.details||`Erreur Supabase (${res.status})`}};
      }
      if(action==='upsert'){
        const onConflict=api._upsertOpts?.onConflict;const path='/rest/v1/'+encodeURIComponent(table)+(onConflict?'?on_conflict='+encodeURIComponent(onConflict):'');
        const res=await apiFetch(path,{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=representation'},body:JSON.stringify(payload)});const data=await readJson(res);return res.ok?{data,error:null}:{data:null,error:{message:data?.message||data?.details||`Erreur Supabase (${res.status})`}};
      }
      return{data:null,error:null};
    }
    return api;
  };
  async function invokeRemote(name,options){const body=options&&Object.prototype.hasOwnProperty.call(options,'body')?options.body:options;let res;try{res=await fetch(SUPABASE_URL+'/functions/v1/'+name,{method:'POST',headers:{apikey:SUPABASE_KEY,'Content-Type':'application/json'},body:JSON.stringify(body||{})})}catch(e){throw new Error('Connexion Supabase impossible : '+(e?.message||String(e)))}const data=await readJson(res);if(!res.ok)return{data:null,error:{message:data?.error||data?.message||`Erreur Supabase (${res.status})`}};return{data,error:null}}
  return{auth,from(table){return builder(table)},functions:{invoke:invokeRemote}};
}
const supabase=makeLocalSupabase();
const root = document.querySelector('#root')

root.innerHTML = `
<div class="app">
  <div class="brand">NOUS SPORT</div>
  <section id="authView" class="panel">
    <div id="authVisual" class="auth-visual">
      <img id="authImage" src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&w=1200&q=85" alt="Sport et entraînement">
      <div class="auth-visual-overlay"><span id="authVisualKicker">NOUS SPORT</span><strong id="authVisualTitle">Prêt à bouger ?</strong></div>
    </div>
    <h1>Ton activité. Tes progrès.</h1>
    <p id="authIntro" class="muted">Connecte-toi pour retrouver tes progrès.</p>
    <div class="tabs"><button id="loginTab" class="secondary">Se connecter</button><button id="signupTab" class="secondary">Créer un compte</button></div>
    <div class="tabs"><button id="loginTab" class="secondary">Se connecter</button><button id="signupTab" class="secondary">Créer un compte</button></div><form id="authForm"><label>Adresse e-mail<div class="email-wrap"><input id="email" type="email" autocomplete="email" list="emailSuggestions" placeholder="ton@email.com" required><datalist id="emailSuggestions"></datalist></div></label><label>Mot de passe<div class="password-wrap"><input id="password" type="password" minlength="6" autocomplete="current-password" required><button id="togglePassword" type="button" class="password-toggle" aria-label="Afficher le mot de passe" aria-pressed="false">Afficher</button></div></label><button id="authSubmit">Se connecter</button></form>
    <p id="authMsg" class="small" aria-live="polite"></p>
  </section>

  <section id="profileView" class="panel hidden">
    <h1>Créer ton profil 👤</h1><p class="muted">Ces informations servent à estimer tes besoins énergétiques.</p>
    <form id="profileForm">
      <label>Sexe<select id="sex" required><option value="">Choisir</option><option value="male">Homme</option><option value="female">Femme</option></select></label>
      <div class="row"><label>Âge<input id="age" type="number" min="13" max="100" required></label><label>Taille (cm)<input id="height" type="number" min="120" max="230" required></label></div>
      <label>Poids (kg)<input id="weight" type="number" min="30" max="300" step="0.1" required></label>
      <label>Activité<select id="activity" required><option value="1.2">Sédentaire</option><option value="1.375">Légèrement actif</option><option value="1.55">Modérément actif</option><option value="1.725">Très actif</option><option value="1.9">Très intense</option></select></label>
      <label>Objectif<select id="goal" required><option value="maintain">Maintenir</option><option value="lose">Perdre du poids</option><option value="gain">Prendre du poids</option></select></label>
      <button>Calculer mes besoins 🔥</button>
    </form>
    <div id="calcResult" class="result hidden"></div><button id="profileContinue" class="secondary hidden" style="margin-top:10px">Continuer vers l'accueil</button>
  </section>

  <section id="homeView" class="hidden home-background">
    <section class="hero"><p class="muted">Tableau de bord</p><h1>Ta journée sportive 💪</h1><p id="welcome" class="muted"></p></section>
    <div class="grid"><article class="stat"><span>🔥 Calories brûlées</span><strong id="calories">0 kcal</strong></article><article class="stat"><span>👟 Pas</span><strong id="steps">0</strong></article><article class="stat"><span>❤️ Fréquence</span><strong id="heart">-- bpm</strong></article><article class="stat"><span>🏋️ Activité</span><strong id="minutes">0 min</strong></article></div>

    <section class="panel goals-panel">
      <h2>🎯 Tes objectifs du jour</h2>
      <div class="rings">
        <div class="ring-card steps-ring-card"><div id="stepsRing" class="ring"><div><strong id="stepsPct">0%</strong><span>Pas</span></div></div><p><b id="stepsGoalValue">0</b> / 10 000 pas</p></div>
        <div class="ring-card food-ring-card"><div id="calRing" class="ring"><div><strong id="calRemaining">0</strong><span>kcal à manger</span></div></div><p><b id="calGoalValue">0</b> kcal restantes / <span id="calTargetValue">0</span> kcal</p></div>
        <div class="ring-card burn-ring-card"><div id="calBurnRing" class="ring"><div><strong id="calBurned">0</strong><span>kcal brûlées</span></div></div><p><b id="calBurnGoalValue">0</b> / <span id="calBurnTargetValue">500</span> kcal brûlées</p></div>
        <div class="ring-card water-ring-card"><div id="waterRing" class="ring"><div><strong id="waterAmount">0</strong><span>ml d'eau</span></div></div><p><b id="waterGoalValue">0</b> / 2 000 ml</p><div class="water-actions"><button id="waterMinus" class="secondary" type="button">−100 ml</button><button id="waterPlus" type="button">+100 ml</button></div></div>
      </div>
      <p id="target" class="muted">Objectif alimentaire : calcul en cours...</p>
      <div class="result">🍽️ Calories consommées : <span id="eaten">0 kcal</span></div>
    </section>

    <section class="panel water-reminder-panel"><h2>💧 Rappels d'hydratation</h2><p class="muted">Nous Sport peut te rappeler de boire toutes les 2 heures. Les rappels sont désactivés la nuit.</p><div class="water-reminder-row"><strong>🔔 Rappel toutes les 2 h</strong><label class="switch-label"><input id="waterReminderToggle" type="checkbox"><span class="switch-slider"></span></label></div><p id="waterReminderStatus" class="small" aria-live="polite"></p></section>

    <section class="panel"><h2>🏃 Ton sport</h2><p class="muted">Choisis une activité puis lance ta séance pour passer en mode entraînement.</p>
      <div class="row"><label>Sport<select id="sportType"><option>Course</option><option>Course sur tapis</option><option>Vélo</option><option>Marche</option><option>Musculation</option><option>Natation</option><option>Autre</option></select></label><label>Durée prévue (min)<input id="sportDuration" type="number" min="1" value="30"></label></div>
      <button id="startWorkout">▶️ Lancer l'entraînement</button><p id="workoutMsg" class="small" aria-live="polite"></p>
    </section>

    <section class="panel"><h2>🤖 Santé Connect Android <span id="liveBadge" class="live-badge hidden">● LIVE</span></h2><p class="muted">Connexion directe aux données de santé Android. Quand Nous Sport est ouvert, les données sont vérifiées automatiquement toutes les 5 secondes.</p>
      <div class="row"><button id="healthConnect">Connecter Santé Connect</button><button id="healthSync" class="secondary">↻ Synchroniser maintenant</button></div><p id="healthConnectMsg" class="small" aria-live="polite"></p><p id="healthLastSync" class="small muted"></p>
    </section>
    <section class="panel"><h2>📸 Ton repas</h2><div class="meal"><strong>Analyse photo du repas</strong><p class="muted">Prends ton repas en photo. L’analyse estime les aliments, les portions et les calories. Tu peux corriger l’estimation avant de l’ajouter à ta journée.</p><input id="mealPhoto" class="meal-photo-input" type="file" accept="image/jpeg,image/png,image/webp" capture="environment"><label for="mealPhoto" class="camera-button">📸 Photographier mon repas</label><div id="mealPreviewWrap" class="meal-preview-wrap hidden"><img id="mealPreview" class="meal-preview" alt="Aperçu du repas"><button id="analyzeMealBtn">🤖 Analyser le repas</button></div><div id="mealStatus" class="small" aria-live="polite"></div></div></section>

    <section id="mealResultPanel" class="panel hidden"><h2>🍽️ Résultat de l’analyse</h2><div id="mealItems" class="meal-items"></div><div class="meal-total"><span>Calories estimées</span><input id="mealCalories" type="number" min="0" step="1"></div><div class="meal-macros"><span>🥩 Protéines <b id="mealProtein">0 g</b></span><span>🍚 Glucides <b id="mealCarbs">0 g</b></span><span>🥑 Lipides <b id="mealFat">0 g</b></span></div><p id="mealConfidence" class="small muted"></p><p id="mealNotes" class="small muted"></p><button id="confirmMeal">➕ Ajouter à mes calories</button><button id="cancelMeal" class="secondary" style="margin-top:8px">Annuler</button></section>
    <section class="panel stats-panel"><h2>📊 Évolution</h2><p class="muted">Tes 7 derniers jours, avec les données reçues de Santé Connect et tes séances.</p><div id="weeklyStats" class="weekly-stats"><p class="small muted">Chargement des statistiques…</p></div></section>
    <div class="nav"><button id="refresh">↻ Actualiser</button><button id="logout" class="danger">Déconnexion</button></div>
  </section>

  <section id="workoutView" class="hidden workout-view">
    <div id="encourageFlash" class="encourage-flash" aria-live="assertive"><div class="flash-inner"><span>💚</span><strong id="encourageText">Tu es en train de progresser !</strong></div></div>
    <div id="completionOverlay" class="completion-overlay hidden" aria-live="assertive">
      <video id="fireworksVideo" class="fireworks-video" muted playsinline preload="auto">
        <source src="fireworks.mp4" type="video/mp4">
      </video>
      <div class="completion-shade"></div>
      <div class="completion-card">
        <div class="completion-icon">👏</div>
        <h2>Félicitations ! 🎉</h2>
        <p id="completionText">Séance terminée !<br><b>Chaque effort compte.</b></p>
        <button id="quitCompletion" class="completion-quit">✓ Quitter</button>
      </div>
    </div>
    <div class="workout-top"><button id="backWorkout" class="secondary compact">← Quitter</button><span id="workoutLive" class="workout-live">● LIVE</span></div>
    <p id="workoutSport" class="muted">Entraînement</p><h1>Ta séance 💪</h1>
    <div class="timer-card"><span>⏱️ Chronomètre</span><strong id="workoutTimer">00:00</strong></div>
    <div class="workout-controls">
      <button id="togglePauseWorkout" class="pause-workout">⏸ Mettre en pause</button>
      <button id="stopWorkout" class="stop-workout">⏹ Terminer la séance</button>
    </div>
    <div class="workout-metrics">
      <article><span>📏 Distance</span><strong id="liveDistance">0,00 km</strong></article>
      <article><span>👟 Pas</span><strong id="liveSteps">0</strong></article>
      <article><span>🔥 Calories</span><strong id="liveCalories">0 kcal</strong></article>
      <article><span>❤️ Fréquence</span><strong id="liveHeart">-- bpm</strong></article>
    </div>
    <div class="live-sync-line"><span id="workoutSync">En attente des données…</span></div>
  </section>
</div>
`

let mode='login'
let workoutState=null, workoutTimerId=null, workoutPollId=null, lastWorkoutData=null;
const show=id=>['authView','profileView','homeView','workoutView'].forEach(x=>$(x).classList.toggle('hidden',x!==id))
const authVisuals={login:{image:'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&w=1200&q=85',alt:'Sport et entraînement',title:'Prêt à bouger ?',intro:'Connecte-toi avec ton adresse e-mail et ton mot de passe.'},signup:{image:'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1200&q=85',alt:'Salle de sport',title:'Ta salle. Tes objectifs.',intro:'Crée ton compte. Tu recevras un e-mail de confirmation.'}}
const EMAIL_MEMORY_KEY='nousSportRememberedEmails';
function loadRememberedEmails(){try{return JSON.parse(localStorage.getItem(EMAIL_MEMORY_KEY)||'[]').filter(x=>typeof x==='string'&&x.includes('@')).slice(0,8)}catch(e){return []}}
function renderRememberedEmails(){const dl=$('emailSuggestions');if(!dl)return;dl.innerHTML=loadRememberedEmails().map(email=>`<option value="${email.replace(/&/g,'&amp;').replace(/"/g,'&quot;')}"></option>`).join('')}
function saveRememberedEmail(email){const value=String(email||'').trim().toLowerCase();if(!value)return;const list=loadRememberedEmails().filter(x=>x!==value);list.unshift(value);try{localStorage.setItem(EMAIL_MEMORY_KEY,JSON.stringify(list.slice(0,8)))}catch(e){}renderRememberedEmails();$('email').value=value}
function setAuthMode(next){mode=next;const v=authVisuals[next];$('authSubmit').textContent=next==='signup'?'Créer mon compte':'Se connecter';$('password').autocomplete=next==='signup'?'new-password':'current-password';$('authImage').src=v.image;$('authImage').alt=v.alt;$('authVisualTitle').textContent=v.title;$('authIntro').textContent=v.intro;$('loginTab').classList.toggle('active',next==='login');$('signupTab').classList.toggle('active',next==='signup')}
$('loginTab').onclick=()=>setAuthMode('login');$('signupTab').onclick=()=>setAuthMode('signup');$('togglePassword').onclick=()=>{const input=$('password');const visible=input.type==='text';input.type=visible?'password':'text';$('togglePassword').textContent=visible?'Afficher':'Masquer';$('togglePassword').setAttribute('aria-label',visible?'Afficher le mot de passe':'Masquer le mot de passe');$('togglePassword').setAttribute('aria-pressed',String(!visible))};setAuthMode('login');renderRememberedEmails()
function caloriesFor(p){const bmr=p.sex==='male'?10*p.weight+6.25*p.height-5*p.age+5:10*p.weight+6.25*p.height-5*p.age-161;const maintenance=bmr*p.activity;const target=p.goal==='lose'?maintenance-300:p.goal==='gain'?maintenance+300:maintenance;return{bmr:Math.round(bmr),maintenance:Math.round(maintenance),target:Math.max(1200,Math.round(target))}}
async function getUser(){const{data:{user}}=await supabase.auth.getUser();return user}
async function load(){const user=await getUser();if(!user){show('authView');return}const{data:profile}=await supabase.from('profiles').select('*').eq('id',user.id).maybeSingle();if(!profile||!profile.sex||!profile.age||!profile.height_cm||!profile.weight_kg){show('profileView');return}showHome(user,profile)}
function waterStorageKey(){return `noussport-water-${localDateKey(new Date())}`}
function getWater(){const saved=Number(localStorage.getItem(waterStorageKey())||0);return Number.isFinite(saved)?Math.max(0,saved):0}
function setWater(value){const amount=Math.min(WATER_GOAL,Math.max(0,Math.round(Number(value||0)/WATER_STEP)*WATER_STEP));localStorage.setItem(waterStorageKey(),String(amount));updateWaterRing(amount);return amount}
function updateWaterRing(amount=getWater()){const ml=Math.max(0,Number(amount||0));const pct=Math.min(100,Math.round((ml/WATER_GOAL)*100));$('waterRing').style.setProperty('--progress',`${pct*3.6}deg`);$('waterAmount').textContent=ml.toLocaleString('fr-FR');$('waterGoalValue').textContent=ml.toLocaleString('fr-FR')}
function updateRings(steps,activeCalories,targetCalories,eatenCalories=0,maintenanceCalories=0){const sp=Math.min(100,Math.round((steps/STEP_GOAL)*100));const baseTarget=Math.max(1,Number(targetCalories||0));const maintenance=Math.max(0,Number(maintenanceCalories||0));const eaten=Math.max(0,Number(eatenCalories||0));const burnGoal=500;const burned=Math.max(0,Number(activeCalories||0));const adjustedTarget=baseTarget+(burned*2);const remaining=Math.max(0,adjustedTarget-eaten);const cp=Math.min(100,Math.round((eaten/adjustedTarget)*100));const bp=Math.min(100,Math.round((burned/burnGoal)*100));const deficit=Math.round(adjustedTarget-eaten);$('stepsRing').style.setProperty('--progress',`${sp*3.6}deg`);$('calRing').style.setProperty('--progress',`${cp*3.6}deg`);$('calBurnRing').style.setProperty('--progress',`${bp*3.6}deg`);$('stepsPct').textContent=`${sp}%`;$('stepsGoalValue').textContent=steps.toLocaleString('fr-FR');$('calRemaining').textContent=Math.round(remaining).toLocaleString('fr-FR');$('calGoalValue').textContent=Math.round(remaining).toLocaleString('fr-FR');$('calTargetValue').textContent=Math.round(adjustedTarget).toLocaleString('fr-FR');$('calBurned').textContent=Math.round(burned).toLocaleString('fr-FR');$('calBurnGoalValue').textContent=Math.round(burned).toLocaleString('fr-FR');$('calBurnTargetValue').textContent=burnGoal.toLocaleString('fr-FR');const warning=deficit<500;$('calWarning').classList.toggle('hidden',!warning);$('calWarning').setAttribute('aria-hidden',String(!warning));$('calWarning').title=`Déficit actuel : ${deficit.toLocaleString('fr-FR')} kcal`;$('calDeficitValue').textContent=`Déficit actuel : ${deficit.toLocaleString('fr-FR')} kcal`;updateWaterRing()}
async function loadWeeklyStats(user){const box=$('weeklyStats');if(!box)return;box.innerHTML='<p class="small muted">Chargement des statistiques…</p>';const end=new Date();const start=new Date(end);start.setDate(end.getDate()-6);const startKey=localDateKey(start);const endKey=localDateKey(end);const [{data:days,error:dayError},{data:workouts,error:workoutError}]=await Promise.all([supabase.from('daily_activity').select('activity_date,steps,active_calories,active_minutes,avg_heart_rate').eq('user_id',user.id).gte('activity_date',startKey).lte('activity_date',endKey).order('activity_date',{ascending:true}),supabase.from('workouts').select('started_at,duration_minutes,calories,avg_heart_rate').eq('user_id',user.id).gte('started_at',`${startKey}T00:00:00`).lte('started_at',`${endKey}T23:59:59.999Z`)]);if(dayError||workoutError){box.innerHTML=`<p class="small">Impossible de charger les statistiques.</p>`;return}const dayMap=new Map((days||[]).map(d=>[d.activity_date,d]));const workoutMap=new Map();for(const w of workouts||[]){const k=localDateKey(w.started_at);const v=workoutMap.get(k)||{minutes:0,calories:0,hearts:[]};v.minutes+=Number(w.duration_minutes||0);v.calories+=Number(w.calories||0);if(w.avg_heart_rate)v.hearts.push(Number(w.avg_heart_rate));workoutMap.set(k,v)}const rows=[];for(let i=0;i<7;i++){const d=new Date(start);d.setDate(start.getDate()+i);const key=localDateKey(d);const a=dayMap.get(key)||{};const w=workoutMap.get(key)||{minutes:0,calories:0,hearts:[]};const heart=a.avg_heart_rate?Number(a.avg_heart_rate):(w.hearts.length?Math.round(w.hearts.reduce((x,y)=>x+y,0)/w.hearts.length):null);rows.push({key,label:d.toLocaleDateString('fr-FR',{weekday:'short',day:'2-digit'}),steps:Number(a.steps||0),calories:Number(a.active_calories||0)+w.calories,minutes:Number(a.active_minutes||0)+w.minutes,heart})}box.innerHTML=rows.map(r=>`<div class="stats-row"><div><strong>${r.label}</strong><span>${r.steps.toLocaleString('fr-FR')} pas</span></div><div><strong>${Math.round(r.calories)} kcal</strong><span>${r.minutes} min${r.heart?` · ${r.heart} bpm`:''}</span></div></div>`).join('');const totalSteps=rows.reduce((s,r)=>s+r.steps,0);const totalCal=rows.reduce((s,r)=>s+r.calories,0);box.insertAdjacentHTML('beforeend',`<div class="stats-summary"><b>${totalSteps.toLocaleString('fr-FR')} pas</b><b>${Math.round(totalCal).toLocaleString('fr-FR')} kcal</b></div>`)}
async function showHome(user,profile){show('homeView');$('welcome').textContent=`Connecté avec ${user.email}`;$('target').textContent=`Objectif alimentaire estimé : ${profile.target_calories||'—'} kcal/jour`;const today=localDateKey(new Date());const{data:a}=await supabase.from('daily_activity').select('*').eq('user_id',user.id).eq('activity_date',today).maybeSingle();const{data:workouts}=await supabase.from('workouts').select('duration_minutes,calories,avg_heart_rate').eq('user_id',user.id).gte('started_at',`${today}T00:00:00`);const workoutMinutes=(workouts||[]).reduce((sum,w)=>sum+(w.duration_minutes||0),0);const workoutCalories=(workouts||[]).reduce((sum,w)=>sum+(w.calories||0),0);const workoutHeart=(workouts||[]).filter(w=>w.avg_heart_rate).map(w=>w.avg_heart_rate);const steps=Number(a?.steps??0);const calories=Number(a?.active_calories??0)+workoutCalories;$('steps').textContent=steps.toLocaleString('fr-FR');$('calories').textContent=`${calories.toLocaleString('fr-FR')} kcal`;const avgWorkoutHeart=workoutHeart.length?Math.round(workoutHeart.reduce((x,y)=>x+y,0)/workoutHeart.length):null;$('heart').textContent=a?.avg_heart_rate?`${a.avg_heart_rate} bpm`:(avgWorkoutHeart?`${avgWorkoutHeart} bpm`:'-- bpm');$('minutes').textContent=`${Number(a?.active_minutes??0)+workoutMinutes} min`;const {data:meals}=await supabase.from('meals').select('calories').eq('user_id',user.id).gte('eaten_at',`${today}T00:00:00`).lt('eaten_at',`${today}T23:59:59.999Z`);const eatenCalories=(meals||[]).reduce((sum,m)=>sum+Number(m.calories||0),0);$('eaten').textContent=`${Math.round(eatenCalories).toLocaleString('fr-FR')} kcal`;updateRings(steps,calories,Number(profile.target_calories||0),eatenCalories,Number(profile.maintenance_calories||0));await loadWeeklyStats(user)}
function formatTime(sec){const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=sec%60;return h?`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`:`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`}
function startWorkout(){const sport=$('sportType').value;workoutState={sport,startedAt:Date.now(),elapsedBeforePause:0,paused:false,resumeRebaseline:false,startSteps:null,startCalories:null,heartSamples:[],distanceStart:null};lastWorkoutData=null;$('workoutSport').textContent=sport;$('togglePauseWorkout').textContent='⏸ Mettre en pause';$('workoutLive').textContent='● LIVE';show('workoutView');$('workoutTimer').textContent='00:00';$('liveDistance').textContent='0,00 km';$('liveSteps').textContent='0';$('liveCalories').textContent='0 kcal';$('liveHeart').textContent='-- bpm';$('workoutSync').textContent='Synchronisation en cours…';clearInterval(workoutTimerId);clearInterval(workoutPollId);workoutTimerId=setInterval(()=>{if(!workoutState||workoutState.paused)return;const sec=Math.floor((workoutState.elapsedBeforePause+(Date.now()-workoutState.startedAt))/1000);$('workoutTimer').textContent=formatTime(sec)},1000);if(window.NousSportHealth){window.NousSportHealth.readToday();workoutPollId=setInterval(()=>{if(workoutState&&!workoutState.paused)window.NousSportHealth.readToday()},5000)}else{$('workoutSync').textContent='La séance LIVE nécessite l’application Android.'}}
function updateWorkout(data){if(!workoutState)return;const steps=Number(data.steps||0),cal=Number(data.active_calories||0),distance=Number(data.distance_km||0);if(workoutState.resumeRebaseline){const keepSteps=Number(workoutState.sessionStepsBeforePause||0),keepCalories=Number(workoutState.sessionCaloriesBeforePause||0),keepDistance=Number(workoutState.sessionDistanceBeforePause||0);workoutState.startSteps=steps-keepSteps;workoutState.startCalories=cal-keepCalories;workoutState.distanceStart=distance-keepDistance;workoutState.resumeRebaseline=false}if(workoutState.startSteps===null)workoutState.startSteps=steps;if(workoutState.startCalories===null)workoutState.startCalories=cal;if(workoutState.distanceStart===null)workoutState.distanceStart=distance;const ds=Math.max(0,steps-workoutState.startSteps),dc=Math.max(0,cal-workoutState.startCalories),dd=Math.max(0,distance-workoutState.distanceStart);$('liveSteps').textContent=ds.toLocaleString('fr-FR');$('liveCalories').textContent=`${Math.round(dc)} kcal`;$('liveDistance').textContent=`${dd.toFixed(2).replace('.',',')} km`;if(data.avg_heart_rate){const hr=Number(data.avg_heart_rate);$('liveHeart').textContent=`${hr} bpm`;if(!workoutState.paused)workoutState.heartSamples.push(hr)}$('workoutSync').textContent=workoutState.paused?'Séance en pause ⏸️':`Données actualisées à ${new Date().toLocaleTimeString('fr-FR')}`;lastWorkoutData={...data,sessionSteps:ds,sessionCalories:dc,sessionDistance:dd}}
const encouragements=['Continue, tu es lancé ! 💪','Encore un effort, tu progresses ! 🔥','Garde ton rythme, c’est ta séance ! 🏃','Bien joué, continue comme ça ! 💚','Tu tiens bon, chaque minute compte ! ⭐']
function flashEncouragement(){const box=$('encourageFlash');$('encourageText').textContent=encouragements[Math.floor(Math.random()*encouragements.length)];box.classList.remove('show');void box.offsetWidth;box.classList.add('show');setTimeout(()=>box.classList.remove('show'),3000)}
function pauseWorkout(){if(!workoutState)return;if(workoutState.paused){workoutState.startedAt=Date.now();workoutState.paused=false;workoutState.resumeRebaseline=true;$('togglePauseWorkout').textContent='⏸ Mettre en pause';$('workoutLive').textContent='● LIVE';$('workoutSync').textContent='Reprise de la séance…';if(window.NousSportHealth){window.NousSportHealth.readToday();clearInterval(workoutPollId);workoutPollId=setInterval(()=>{if(workoutState&&!workoutState.paused)window.NousSportHealth.readToday()},5000)}return}workoutState.elapsedBeforePause+=(Date.now()-workoutState.startedAt);workoutState.paused=true;workoutState.sessionStepsBeforePause=Number(lastWorkoutData?.sessionSteps||0);workoutState.sessionCaloriesBeforePause=Number(lastWorkoutData?.sessionCalories||0);workoutState.sessionDistanceBeforePause=Number(lastWorkoutData?.sessionDistance||0);clearInterval(workoutPollId);$('togglePauseWorkout').textContent='▶ Reprendre';$('workoutLive').textContent='⏸ PAUSE';$('workoutSync').textContent='Séance en pause ⏸️'}
function stopWorkout(){if(!workoutState)return;clearInterval(workoutTimerId);clearInterval(workoutPollId);const elapsed=workoutState.elapsedBeforePause+(workoutState.paused?0:Date.now()-workoutState.startedAt);const duration=Math.max(1,Math.round(elapsed/60000));const calories=Math.round(lastWorkoutData?.sessionCalories||0);const heartSamples=workoutState.heartSamples||[];const heart=heartSamples.length?Math.round(heartSamples.reduce((a,b)=>a+b,0)/heartSamples.length):null;const state={sport:workoutState.sport,duration,calories,heart};workoutState=null;lastWorkoutData=null;saveWorkoutData(state)}
function playCelebrationSound(){try{const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;const ctx=new AC();const master=ctx.createGain();master.gain.value=.22;master.connect(ctx.destination);const now=ctx.currentTime;const duration=5;const buffer=ctx.createBuffer(1,Math.floor(ctx.sampleRate*duration),ctx.sampleRate);const ch=buffer.getChannelData(0);for(let i=0;i<ch.length;i++){const t=i/ctx.sampleRate;const envelope=Math.max(0,1-t/duration);const burst=Math.random()<0.035?1:0;ch[i]=(Math.random()*2-1)*burst*envelope*0.7}const src=ctx.createBufferSource();src.buffer=buffer;const g=ctx.createGain();g.gain.setValueAtTime(.02,now);g.gain.linearRampToValueAtTime(1,now+.12);g.gain.setValueAtTime(.75,now+3.8);g.gain.linearRampToValueAtTime(.02,now+duration);src.connect(g).connect(master);src.start(now);src.stop(now+duration);[523.25,659.25,783.99,1046.5,783.99,1046.5,1318.51].forEach((freq,i)=>{const o=ctx.createOscillator(),og=ctx.createGain();const t0=now+i*.55;o.type='sine';o.frequency.value=freq;og.gain.setValueAtTime(0,t0);og.gain.linearRampToValueAtTime(.12,t0+.03);og.gain.exponentialRampToValueAtTime(.001,t0+.48);o.connect(og).connect(master);o.start(t0);o.stop(t0+.5)});setTimeout(()=>ctx.close(),5200)}catch(e){}}
function showCompletion(){const box=$('completionOverlay');const video=$('fireworksVideo');const phrases=['Bravo ! Tu viens de terminer ta séance 💪','Excellent travail ! Chaque effort compte 🔥','Séance terminée ! Tu peux être fier de ton effort ⭐','Bien joué ! Encore une séance accomplie 🎉'];$('completionText').innerHTML=phrases[Math.floor(Math.random()*phrases.length)];box.classList.remove('hidden');try{video.currentTime=0;video.play().catch(()=>{});setTimeout(()=>{try{video.pause()}catch(e){}},5000)}catch(e){}playCelebrationSound()}
async function saveWorkoutData(state){const user=await getUser();if(!user)return;$('workoutSync').textContent='Enregistrement de la séance…';const{error}=await supabase.from('workouts').insert({user_id:user.id,sport:state.sport,duration_minutes:state.duration,calories:state.calories,avg_heart_rate:state.heart});if(error){$('workoutSync').textContent=`Erreur : ${error.message}`;return}$('workoutSync').textContent='Séance enregistrée ✅';showCompletion()}
function dateKeyFromApple(value){if(!value)return null;const m=String(value).match(/^(\d{4}-\d{2}-\d{2})/);return m?m[1]:null}
function localDateKey(date){const d=new Date(date);if(Number.isNaN(d.getTime()))return null;const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');return`${y}-${m}-${day}`}
function numAttr(el,name){const n=Number(el.getAttribute(name));return Number.isFinite(n)?n:0}

function setReminderStatus(message){if($('waterReminderStatus'))$('waterReminderStatus').textContent=message}
function syncWaterReminderUi(){const enabled=localStorage.getItem('noussport-water-reminders')==='1';if($('waterReminderToggle'))$('waterReminderToggle').checked=enabled;setReminderStatus(enabled?'Rappels actifs : toutes les 2 h, de 8 h à 20 h.':'Rappels désactivés.')}
function setWaterReminders(enabled){localStorage.setItem('noussport-water-reminders',enabled?'1':'0');if(window.NousSportHealth?.setWaterReminders){window.NousSportHealth.setWaterReminders(enabled);setReminderStatus(enabled?'Rappels actifs : toutes les 2 h, de 8 h à 20 h.':'Rappels désactivés.')}else if(enabled){setReminderStatus('Les rappels sont disponibles dans la version Android de Nous Sport.')}else{setReminderStatus('Rappels désactivés.')}}

window.__healthData=async data=>{const now=new Date();$('liveBadge')?.classList.remove('hidden');$('healthLastSync').textContent=`Dernière mise à jour : ${now.toLocaleTimeString('fr-FR')}`;if(workoutState){updateWorkout(data);return}const user=await getUser();if(!user)return;const today=localDateKey(new Date());const row={user_id:user.id,activity_date:today,steps:Number(data.steps||0),active_calories:Math.round(Number(data.active_calories||0)),avg_heart_rate:data.avg_heart_rate==null?null:Math.round(Number(data.avg_heart_rate)),active_minutes:0};const{error}=await supabase.from('daily_activity').upsert(row,{onConflict:'user_id,activity_date'});if(error){$('healthConnectMsg').textContent=`Erreur Supabase : ${error.message}`;return}$('healthConnectMsg').textContent=`Synchronisé ✅ ${row.steps.toLocaleString('fr-FR')} pas, ${row.active_calories} kcal actives`+(row.avg_heart_rate?`, ${row.avg_heart_rate} bpm`:'');await showHome(user,await supabase.from('profiles').select('*').eq('id',user.id).single().then(r=>r.data))}
window.__healthError=msg=>{$('healthConnectMsg').textContent=`Santé Connect : ${msg}`;if(workoutState)$('workoutSync').textContent=`Santé Connect : ${msg}`}
if(window.NousSportHealth){$('healthConnect').onclick=()=>{$('healthConnectMsg').textContent='Ouverture des autorisations Santé Connect…';NousSportHealth.requestPermissions()};$('healthSync').onclick=()=>{$('healthConnectMsg').textContent='Synchronisation…';NousSportHealth.readToday()};$('healthConnect').disabled=false}else{$('healthConnect').onclick=()=>{$('healthConnectMsg').textContent='Cette fonction est disponible dans l’application Android.'};$('healthSync').onclick=()=>{$('healthConnectMsg').textContent='Ouvre la version Android de Nous Sport pour utiliser Santé Connect.'}}

$('waterPlus').onclick=()=>setWater(getWater()+WATER_STEP);$('waterMinus').onclick=()=>setWater(getWater()-WATER_STEP);$('waterReminderToggle').onchange=e=>setWaterReminders(e.target.checked);syncWaterReminderUi();updateWaterRing();

$('authForm').onsubmit=async e=>{e.preventDefault();const email=$('email').value.trim().toLowerCase(),password=$('password').value;if(!email||!password)return;saveRememberedEmail(email);$('authMsg').textContent=mode==='signup'?'Création du compte…':'Connexion en cours…';const result=mode==='signup'?await supabase.auth.signUp({email,password}):await supabase.auth.signInWithPassword({email,password});if(result.error){$('authMsg').textContent=`Erreur : ${result.error.message}`;return}if(mode==='signup'){if(result.data?.session){$('authMsg').textContent='Compte créé. Tu es connecté.';await load()}else{$('authMsg').textContent='Compte créé. Vérifie ton e-mail de confirmation, puis connecte-toi avec ton adresse e-mail et ton mot de passe.';setAuthMode('login')}}else{$('authMsg').textContent='Connecté.';await load()}}
$('profileForm').onsubmit=async e=>{e.preventDefault();const user=await getUser();if(!user){show('authView');return}const p={sex:$('sex').value,age:Number($('age').value),height:Number($('height').value),weight:Number($('weight').value),activity:Number($('activity').value),goal:$('goal').value};const c=caloriesFor(p);const{error}=await supabase.from('profiles').upsert({id:user.id,sex:p.sex,age:p.age,height_cm:p.height,weight_kg:p.weight,activity_factor:p.activity,goal:p.goal,bmr:c.bmr,maintenance_calories:c.maintenance,target_calories:c.target});if(error){$('calcResult').classList.remove('hidden');$('calcResult').textContent=`Erreur Supabase : ${error.message}`;return}$('calcResult').classList.remove('hidden');$('calcResult').textContent=`🔥 Besoins estimés : ${c.maintenance} kcal/jour · 🎯 Objectif : ${c.target} kcal/jour`;$('profileContinue').classList.remove('hidden')}
$('profileContinue').onclick=load;$('refresh').onclick=load;$('logout').onclick=async()=>{await supabase.auth.signOut();load()};$('startWorkout').onclick=startWorkout;$('stopWorkout').onclick=stopWorkout;$('togglePauseWorkout').onclick=pauseWorkout;$('quitCompletion').onclick=async()=>{const video=$('fireworksVideo');try{video.pause();video.currentTime=0}catch(e){}$('completionOverlay').classList.add('hidden');const user=await getUser();if(user){const{data:profile}=await supabase.from('profiles').select('*').eq('id',user.id).single();showHome(user,profile)}};$('backWorkout').onclick=()=>{clearInterval(workoutTimerId);clearInterval(workoutPollId);workoutState=null;lastWorkoutData=null;show('homeView');load()}

function resizeImage(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>{const img=new Image();img.onload=()=>{const max=1600;const scale=Math.min(1,max/Math.max(img.width,img.height));const canvas=document.createElement('canvas');canvas.width=Math.round(img.width*scale);canvas.height=Math.round(img.height*scale);canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);resolve(canvas.toDataURL('image/jpeg',.82))};img.onerror=reject;img.src=reader.result};reader.onerror=reject;reader.readAsDataURL(file)})}
$('mealPhoto').onchange=async e=>{const file=e.target.files?.[0];if(!file)return;try{mealImageDataUrl=await resizeImage(file);$('mealPreview').src=mealImageDataUrl;$('mealPreviewWrap').classList.remove('hidden');$('mealResultPanel').classList.add('hidden');$('mealStatus').textContent='Photo prête. Appuie sur « Analyser le repas ». '}catch(err){$('mealStatus').textContent='Impossible de lire cette photo.'}}
function showMealToast(message){const toast=$('mealToast');if(!toast)return;toast.textContent=message;toast.classList.remove('hidden');clearTimeout(window.__mealToastTimer);window.__mealToastTimer=setTimeout(()=>toast.classList.add('hidden'),3000)}
$('analyzeMealBtn').onclick=async()=>{if(!mealImageDataUrl){$('mealStatus').textContent='Choisis d’abord une photo.';return}$('mealStatus').textContent='🤖 Analyse du repas en cours…';$('analyzeMealBtn').disabled=true;try{const {data,error}=await supabase.functions.invoke('analyze-meal',{body:{imageDataUrl:mealImageDataUrl,mimeType:'image/jpeg'}});if(error||data?.error)throw new Error(data?.error||error?.message||'Analyse indisponible');pendingMeal=data;$('mealItems').innerHTML=(data.items||[]).map(i=>`<div class="meal-item"><b>${i.name}</b><span>${i.portion}</span><strong>${Math.round(i.calories)} kcal</strong></div>`).join('')||'<p class="muted">Aucun aliment identifiable.</p>';$('mealCalories').value=Math.round(data.total_calories||0);$('mealProtein').textContent=`${Math.round(data.protein_g||0)} g`;$('mealCarbs').textContent=`${Math.round(data.carbs_g||0)} g`;$('mealFat').textContent=`${Math.round(data.fat_g||0)} g`;$('mealConfidence').textContent=`Confiance : ${data.confidence==='high'?'élevée':data.confidence==='low'?'faible':'moyenne'}`;$('mealNotes').textContent=data.notes||'';$('mealResultPanel').classList.remove('hidden');$('mealStatus').textContent='Analyse terminée. Vérifie les calories avant de valider.'}catch(err){$('mealStatus').textContent=`Erreur : ${err.message}`}finally{$('analyzeMealBtn').disabled=false}}
$('confirmMeal').onclick=async()=>{
  const button=$('confirmMeal');
  if(!pendingMeal){$('mealStatus').textContent='⚠️ Aucun repas à ajouter. Relance l’analyse du repas.';return}
  const calories=Math.max(0,Math.round(Number($('mealCalories').value||0)));
  if(calories<=0){$('mealStatus').textContent='⚠️ Indique une quantité de calories supérieure à 0.';return}
  const user=await getUser();
  if(!user){$('mealStatus').textContent='⚠️ Session expirée. Reconnecte-toi.';return}
  button.disabled=true;
  $('mealStatus').textContent='⏳ Ajout du repas à tes calories…';
  try{
    const fullPayload={
      user_id:user.id,
      name:pendingMeal.meal_name||'Repas',
      calories,
      protein_g:Number(pendingMeal.protein_g||0),
      carbs_g:Number(pendingMeal.carbs_g||0),
      fat_g:Number(pendingMeal.fat_g||0),
      items:pendingMeal.items||[],
      confidence:pendingMeal.confidence||'medium',
      notes:pendingMeal.notes||null,
      eaten_at:new Date().toISOString()
    };
    let result=await supabase.from('meals').insert(fullPayload);
    if(result.error){
      const minimalPayload={user_id:user.id,calories,eaten_at:new Date().toISOString()};
      result=await supabase.from('meals').insert(minimalPayload);
    }
    if(result.error)throw new Error(result.error.message||'Impossible d’enregistrer le repas.');
    pendingMeal=null;
    mealImageDataUrl=null;
    $('mealPhoto').value='';
    $('mealPreviewWrap').classList.add('hidden');
    $('mealResultPanel').classList.add('hidden');
    $('mealStatus').textContent=`Repas ajouté : ${calories.toLocaleString('fr-FR')} kcal ✅`;
    showMealToast(`✅ ${calories.toLocaleString('fr-FR')} kcal ajoutées à ta journée`);
    await load();
  }catch(err){
    $('mealStatus').textContent=`❌ ${err.message||'Erreur lors de l’ajout du repas.'}`;
  }finally{
    button.disabled=false;
  }
}
$('cancelMeal').onclick=()=>{$('mealResultPanel').classList.add('hidden');pendingMeal=null}

supabase.auth.onAuthStateChange(()=>load());load()
