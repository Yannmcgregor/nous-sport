package com.noussport.app

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.TextView

class PermissionsRationaleActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val text = TextView(this).apply {
            text = "Nous Sport\n\nNous Sport demande l'accès en lecture à tes données d'activité (pas, calories, distance et fréquence cardiaque) afin d'afficher tes statistiques sportives.\n\nCes données sont utilisées pour les fonctionnalités de santé et de suivi sportif de Nous Sport."
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(48, 48, 48, 48)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(17, 24, 39))
        }
        setContentView(text)
    }
}
