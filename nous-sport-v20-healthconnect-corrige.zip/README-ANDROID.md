# Nous Sport V5 LIVE Android

Cette version ajoute :
- Santé Connect Android avec lecture pas, calories actives, fréquence cardiaque et distance.
- Synchronisation toutes les 5 secondes tant que l'application est ouverte.
- Anneaux de progression : 10 000 pas et 500 kcal actives.
- Suppression de l'import Apple Santé de l'interface.
- Nouveau sport : Course sur tapis.
- Mode entraînement dédié : chronomètre, distance, pas, calories, fréquence cardiaque.
- Flash vert de 3 secondes et message d'encouragement toutes les 5 minutes pendant une séance.

Les nouvelles données affichées dépendent de ce que Santé Connect et le capteur/montre ont réellement enregistré.

## Analyse photo des repas
La V12 ajoute une capture photo du repas et une analyse nutritionnelle par IA. Pour des raisons de sécurité, la clé OpenAI n'est jamais embarquée dans l'application. L'analyse passe par la fonction Supabase `analyze-meal`.

1. Appliquer `supabase/migrations/20260924_meals.sql` dans le SQL Editor de Supabase.
2. Déployer `supabase/functions/analyze-meal/index.ts` comme Edge Function nommée `analyze-meal`.
3. Dans Supabase > Edge Functions > Secrets, ajouter `OPENAI_API_KEY` avec la clé API OpenAI. Tu peux aussi ajouter `OPENAI_MODEL` si tu veux choisir explicitement le modèle vision. Les secrets de production sont conservés côté serveur et ne doivent pas être mis dans l'application. 
4. L'utilisateur se connecte, prend une photo, lance l'analyse, vérifie/modifie les calories estimées, puis appuie sur « Ajouter à mes calories ».

L'image n'est pas enregistrée par l'application dans Supabase. Seuls les résultats nutritionnels validés sont enregistrés dans la table `meals`.


## Correction de compilation JVM
La configuration Android utilise Java 17 pour la compilation Java et Kotlin afin d'éviter le conflit de cible JVM Java 1.8 / Kotlin 17.


## Correction AGP 8.9.1
Le plugin Android Gradle a été mis à jour de 8.7.3 à 8.9.1, car les dépendances AndroidX utilisées par Nous Sport exigent AGP 8.9.1 ou supérieur.

## V14 - correctif de démarrage Android
La V13 chargeait directement le code source Vite (`import`, `import.meta.env` et `@supabase/supabase-js`) dans un WebView `file://`. Cela provoquait la fermeture immédiate de l'application avant affichage de l'interface. La V14 utilise une page WebView autonome et un stockage local de secours, et initialise Santé Connect uniquement si le fournisseur est disponible. Le rafraîchissement LIVE reste à 5 secondes lorsque Santé Connect est autorisé.


## V20 Health Connect correction
- Le bouton Connecter Santé Connect vérifie d'abord les permissions réellement accordées.
- Si des permissions manquent, l'écran de demande Health Connect est lancé avec uniquement les permissions manquantes.
- Si Android a bloqué les demandes répétées, l'application ouvre directement la gestion des permissions de Nous Sport.
- Correction du pont JavaScript : les données Android sont envoyées vers `window.__healthData(...)`.
- Ajout de l'activité de justification des permissions Health Connect.
