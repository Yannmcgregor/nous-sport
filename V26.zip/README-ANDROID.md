Nous Sport V23

V23 corrige l’affichage des statistiques 7 jours dans le runtime Android local et conserve la prise de photo des repas.
