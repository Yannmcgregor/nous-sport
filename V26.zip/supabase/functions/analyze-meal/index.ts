const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

function response(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (req.method !== 'POST') return response({ error: 'Method not allowed' }, 405)

  const apiKey = Deno.env.get('OPENAI_API_KEY')
  if (!apiKey) return response({ error: 'OPENAI_API_KEY n’est pas configurée dans Supabase.' }, 500)

  const { imageDataUrl } = await req.json().catch(() => ({ imageDataUrl: null }))
  if (typeof imageDataUrl !== 'string' || !imageDataUrl.startsWith('data:image/')) {
    return response({ error: 'Image invalide.' }, 400)
  }
  if (imageDataUrl.length > 8_000_000) return response({ error: 'Photo trop volumineuse. Reprends une photo.' }, 413)

  const model = Deno.env.get('OPENAI_MODEL') || 'gpt-5.6-luna'
  const prompt = `Analyse cette photo de repas pour une application de suivi alimentaire.
Identifie les aliments visibles et estime les portions. Donne une estimation raisonnable des calories et des macronutriments. Ne prétends jamais connaître une quantité exacte à partir d’une photo. Si une portion est incertaine, indique-le.
Réponds UNIQUEMENT avec un JSON valide de la forme:
{
  "meal_name": "...",
  "items": [{"name":"...","portion":"...","calories":123,"protein_g":12,"carbs_g":20,"fat_g":5}],
  "total_calories": 456,
  "protein_g": 20,
  "carbs_g": 40,
  "fat_g": 15,
  "confidence": "low|medium|high",
  "notes": "..."
}
Les calories doivent être des nombres entiers et les macros des nombres. Si aucun repas identifiable n’est visible, retourne total_calories=0 et explique pourquoi dans notes.`

  const openaiRes = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model,
      input: [{
        role: 'user',
        content: [
          { type: 'input_text', text: prompt },
          { type: 'input_image', image_url: imageDataUrl, detail: 'auto' },
        ],
      }],
      max_output_tokens: 900,
    }),
  })

  const raw = await openaiRes.text()
  if (!openaiRes.ok) return response({ error: `Analyse IA indisponible (${openaiRes.status}).` }, 502)

  let payload: any
  try { payload = JSON.parse(raw) } catch { return response({ error: 'Réponse IA invalide.' }, 502) }
  const text = payload.output_text || payload.output?.flatMap((x: any) => x.content || []).find((x: any) => x.type === 'output_text')?.text || ''
  let result: any
  try { result = JSON.parse(text) } catch {
    const match = text.match(/\{[\s\S]*\}/)
    if (!match) return response({ error: 'Impossible de lire le résultat de l’analyse.' }, 502)
    try { result = JSON.parse(match[0]) } catch { return response({ error: 'Impossible de lire le résultat de l’analyse.' }, 502) }
  }

  const cleanItems = Array.isArray(result.items) ? result.items.map((i: any) => ({
    name: String(i?.name || 'Aliment'),
    portion: String(i?.portion || 'portion estimée'),
    calories: Math.max(0, Math.round(Number(i?.calories || 0))),
    protein_g: Math.max(0, Number(i?.protein_g || 0)),
    carbs_g: Math.max(0, Number(i?.carbs_g || 0)),
    fat_g: Math.max(0, Number(i?.fat_g || 0)),
  })) : []

  return response({
    meal_name: String(result.meal_name || 'Repas'),
    items: cleanItems,
    total_calories: Math.max(0, Math.round(Number(result.total_calories ?? cleanItems.reduce((s: number, i: any) => s + i.calories, 0)))),
    protein_g: Math.max(0, Number(result.protein_g || 0)),
    carbs_g: Math.max(0, Number(result.carbs_g || 0)),
    fat_g: Math.max(0, Number(result.fat_g || 0)),
    confidence: ['low', 'medium', 'high'].includes(result.confidence) ? result.confidence : 'medium',
    notes: String(result.notes || 'Les valeurs sont des estimations basées sur la photo.'),
  })
})
