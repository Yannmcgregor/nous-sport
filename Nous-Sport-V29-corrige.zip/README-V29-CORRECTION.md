# Nous Sport V29

Correction principale :
- Le WebView ne remplace plus toute l'application lorsqu'une ressource secondaire
  (photo distante, etc.) échoue avec `net::ERR_NAME_NOT_RESOLVED`.
- L'écran d'erreur natif n'est maintenant affiché que si la page principale
  `file:///android_asset/...` échoue réellement.
- La connexion Supabase, l'analyse photo des repas, Santé Connect et les fonctions
  existantes de V28 sont conservées.
