package com.noussport.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var health: HealthConnectClient? = null
    private val liveHandler = Handler(Looper.getMainLooper())
    private val liveIntervalMs = 5_000L
    private var liveRunning = false
    private val liveSync = object : Runnable {
        override fun run() {
            if (!liveRunning) return
            readHealth()
            liveHandler.postDelayed(this, liveIntervalMs)
        }
    }
    private val permissions = setOf(
        "android.permission.health.READ_STEPS",
        "android.permission.health.READ_HEART_RATE",
        "android.permission.health.READ_ACTIVE_CALORIES_BURNED",
        "android.permission.health.READ_EXERCISE",
        "android.permission.health.READ_DISTANCE"
    )
    private val requestPermissions = registerForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { readHealth() }
    private val requestNotificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createWaterNotificationChannel()
        try {
            val sdkStatus = HealthConnectClient.getSdkStatus(this)
            if (sdkStatus == HealthConnectClient.SDK_AVAILABLE) {
                health = HealthConnectClient.getOrCreate(this)
            }
        } catch (_: Exception) {
            health = null
        }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            webViewClient = WebViewClient()
            addJavascriptInterface(Bridge(), "NousSportHealth")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (WaterReminderScheduler.isEnabled(this)) WaterReminderScheduler.scheduleNext(this)
    }

    override fun onResume() {
        super.onResume()
        liveRunning = true
        liveHandler.removeCallbacks(liveSync)
        liveHandler.post(liveSync)
    }

    override fun onPause() {
        liveRunning = false
        liveHandler.removeCallbacks(liveSync)
        super.onPause()
    }

    override fun onDestroy() {
        liveRunning = false
        liveHandler.removeCallbacks(liveSync)
        web.destroy()
        super.onDestroy()
    }

    inner class Bridge {
        @JavascriptInterface fun isAvailable(): Boolean =
            try { HealthConnectClient.getSdkStatus(this@MainActivity) == HealthConnectClient.SDK_AVAILABLE } catch (_: Exception) { false }
        @JavascriptInterface fun requestPermissions() {
            runOnUiThread { requestPermissions.launch(permissions) }
        }
        @JavascriptInterface fun readToday() { readHealth() }
        @JavascriptInterface fun setWaterReminders(enabled: Boolean) {
            if (enabled) {
                WaterReminderScheduler.enable(this@MainActivity)
                if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread { requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS) }
                }
            } else {
                WaterReminderScheduler.disable(this@MainActivity)
            }
        }
    }

    private fun createWaterNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val channel = android.app.NotificationChannel(
                WaterReminderScheduler.CHANNEL_ID,
                "Rappels d'hydratation",
                android.app.NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "Rappels Nous Sport toutes les 2 heures" }
            getSystemService(android.app.NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun readHealth() {
        val healthClient = health
        if (healthClient == null) {
            runOnUiThread { web.evaluateJavascript("window.__healthError && window.__healthError('Santé Connect n’est pas disponible sur cet appareil')", null) }
            return
        }
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val granted = healthClient.permissionController.getGrantedPermissions()
                if (!granted.containsAll(permissions)) {
                    runOnUiThread { web.evaluateJavascript("window.__healthError && window.__healthError('Autorisation Santé Connect requise')", null) }
                    return@launch
                }
                val zone = ZoneId.systemDefault()
                val start = ZonedDateTime.now(zone).toLocalDate().atStartOfDay(zone).toInstant()
                val end = Instant.now()
                val range = TimeRangeFilter.between(start, end)
                val steps = healthClient.aggregate(AggregateRequest(setOf(StepsRecord.COUNT_TOTAL), range)).get(StepsRecord.COUNT_TOTAL) ?: 0L
                val calories = healthClient.aggregate(AggregateRequest(setOf(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL), range)).get(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL)?.inKilocalories ?: 0.0
                val hr = healthClient.aggregate(AggregateRequest(setOf(HeartRateRecord.BPM_AVG), range)).get(HeartRateRecord.BPM_AVG)?.toInt()
                val distance = healthClient.aggregate(AggregateRequest(setOf(DistanceRecord.DISTANCE_TOTAL), range)).get(DistanceRecord.DISTANCE_TOTAL)?.inKilometers ?: 0.0
                val json = "{\"steps\":$steps,\"active_calories\":${calories.toInt()},\"avg_heart_rate\":${hr ?: "null"},\"distance_km\":$distance}"
                runOnUiThread { web.evaluateJavascript("window.__healthData && window.__healthData($json)", null) }
            } catch (e: Exception) {
                val msg = e.message?.replace("'", "\\'") ?: "Erreur Santé Connect"
                runOnUiThread { web.evaluateJavascript("window.__healthError && window.__healthError('$msg')", null) }
            }
        }
    }
}
